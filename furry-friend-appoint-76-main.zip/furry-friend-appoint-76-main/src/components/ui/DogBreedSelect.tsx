
import { useState } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useDogBreeds } from "@/contexts/DogBreedContext";

interface DogBreedSelectProps {
  value: string;
  onValueChange: (value: string) => void;
}

const DogBreedSelect = ({ value, onValueChange }: DogBreedSelectProps) => {
  const { breeds } = useDogBreeds();

  return (
    <Select value={value} onValueChange={onValueChange}>
      <SelectTrigger>
        <SelectValue placeholder="Selecione a raça" />
      </SelectTrigger>
      <SelectContent className="bg-background border shadow-lg z-50 max-h-60 overflow-y-auto">
        {breeds.map((breed) => (
          <SelectItem key={breed} value={breed}>
            {breed}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
};

export default DogBreedSelect;

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { Building2, Save, MapPin, Phone, Mail, Clock, ExternalLink, Copy } from "lucide-react";
import { useCompanyData } from "@/contexts/CompanyDataContext";
import { generateSlugFromName } from "@/hooks/useCompanySlug";

const CompanyDataManager = () => {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const { companyData, updateCompanyData } = useCompanyData();

  // Generate client URL based on company name
  const companySlug = generateSlugFromName(companyData.name || "");
  const clientUrl = companySlug ? `${window.location.origin}/${companySlug}/cliente` : "";

  const copyUrlToClipboard = () => {
    if (clientUrl) {
      navigator.clipboard.writeText(clientUrl);
      toast({
        title: "URL copiada!",
        description: "A URL do cliente foi copiada para a área de transferência.",
      });
    }
  };

  const dayNames = {
    monday: "Segunda-feira",
    tuesday: "Terça-feira", 
    wednesday: "Quarta-feira",
    thursday: "Quinta-feira",
    friday: "Sexta-feira",
    saturday: "Sábado",
    sunday: "Domingo"
  };

  const handleCepChange = async (cep: string) => {
    const cleanCep = cep.replace(/\D/g, '');
    
    updateCompanyData({ cep: formatCep(cleanCep) });

    if (cleanCep.length === 8) {
      setIsLoading(true);
      try {
        const response = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`);
        const addressData = await response.json();
        
        if (addressData && !addressData.erro) {
          updateCompanyData({
            address: addressData.logradouro || "",
            neighborhood: addressData.bairro || "",
            city: addressData.localidade || "",
            state: addressData.uf || ""
          });
          
          toast({
            title: "Endereço encontrado!",
            description: "Os dados do endereço foram preenchidos automaticamente.",
          });
        } else {
          toast({
            title: "CEP não encontrado",
            description: "Verifique se o CEP está correto.",
            variant: "destructive"
          });
        }
      } catch (error) {
        console.error("Erro ao buscar CEP:", error);
        toast({
          title: "Erro ao buscar CEP",
          description: "Tente novamente em alguns instantes.",
          variant: "destructive"
        });
      } finally {
        setIsLoading(false);
      }
    }
  };

  const formatCep = (cep: string) => {
    return cep.replace(/(\d{5})(\d{3})/, '$1-$2');
  };

  const formatPhone = (phone: string) => {
    const cleanPhone = phone.replace(/\D/g, '');
    return cleanPhone.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
  };

  const handleWorkingHoursChange = (day: keyof typeof companyData.workingHours, field: 'start' | 'end' | 'lunchStart' | 'lunchEnd' | 'isOpen' | 'hasLunchBreak', value: string | boolean) => {
    updateCompanyData({
      workingHours: {
        ...companyData.workingHours,
        [day]: {
          ...companyData.workingHours[day],
          [field]: value
        }
      }
    });
  };

  const handleSave = () => {
    toast({
      title: "Dados salvos com sucesso!",
      description: "As informações da empresa foram atualizadas.",
    });
  };

  return (
    <div className="space-y-6">
      {/* Dados Básicos */}
      <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Building2 className="h-5 w-5 mr-2 text-indigo-600" />
            Informações Básicas
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">Nome da Empresa</Label>
              <Input
                id="name"
                value={companyData.name}
                onChange={(e) => updateCompanyData({ name: e.target.value })}
                placeholder="Nome da empresa"
              />
            </div>
            <div>
              <Label htmlFor="phone">Telefone Celular</Label>
              <Input
                id="phone"
                value={companyData.phone}
                onChange={(e) => updateCompanyData({ phone: formatPhone(e.target.value) })}
                placeholder="(11) 99999-9999"
              />
            </div>
            <div className="md:col-span-2">
              <Label htmlFor="email">E-mail</Label>
              <Input
                id="email"
                type="email"
                value={companyData.email}
                onChange={(e) => updateCompanyData({ email: e.target.value })}
                placeholder="contato@empresa.com"
              />
            </div>
            {clientUrl && (
              <div className="md:col-span-2">
                <Label>URL de Acesso para Clientes</Label>
                <div className="flex items-center space-x-2 mt-1">
                  <Input
                    value={clientUrl}
                    readOnly
                    className="bg-gray-50"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={copyUrlToClipboard}
                    className="shrink-0"
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => window.open(clientUrl, '_blank')}
                    className="shrink-0"
                  >
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-sm text-gray-600 mt-1">
                  Compartilhe esta URL com seus clientes para que eles possam acessar o sistema de agendamentos.
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Endereço */}
      <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center">
            <MapPin className="h-5 w-5 mr-2 text-indigo-600" />
            Endereço
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="cep">CEP</Label>
              <Input
                id="cep"
                value={companyData.cep}
                onChange={(e) => handleCepChange(e.target.value)}
                placeholder="00000-000"
                disabled={isLoading}
              />
              {isLoading && <p className="text-sm text-gray-500 mt-1">Buscando endereço...</p>}
            </div>
            <div className="md:col-span-2">
              <Label htmlFor="address">Endereço</Label>
              <Input
                id="address"
                value={companyData.address}
                onChange={(e) => updateCompanyData({ address: e.target.value })}
                placeholder="Rua, avenida..."
              />
            </div>
            <div>
              <Label htmlFor="addressNumber">Número</Label>
              <Input
                id="addressNumber"
                value={companyData.addressNumber}
                onChange={(e) => updateCompanyData({ addressNumber: e.target.value })}
                placeholder="123"
              />
            </div>
            <div>
              <Label htmlFor="complement">Complemento</Label>
              <Input
                id="complement"
                value={companyData.complement}
                onChange={(e) => updateCompanyData({ complement: e.target.value })}
                placeholder="Sala, andar..."
              />
            </div>
            <div>
              <Label htmlFor="neighborhood">Bairro</Label>
              <Input
                id="neighborhood"
                value={companyData.neighborhood}
                onChange={(e) => updateCompanyData({ neighborhood: e.target.value })}
                placeholder="Bairro"
              />
            </div>
            <div>
              <Label htmlFor="city">Cidade</Label>
              <Input
                id="city"
                value={companyData.city}
                onChange={(e) => updateCompanyData({ city: e.target.value })}
                placeholder="Cidade"
              />
            </div>
            <div>
              <Label htmlFor="state">Estado</Label>
              <Input
                id="state"
                value={companyData.state}
                onChange={(e) => updateCompanyData({ state: e.target.value })}
                placeholder="SP"
                maxLength={2}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Horários de Funcionamento */}
      <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Clock className="h-5 w-5 mr-2 text-indigo-600" />
            Horários de Funcionamento
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-1">
            {Object.entries(companyData.workingHours).map(([day, schedule]) => (
              <div key={day} className="flex items-center space-x-4 p-2 bg-gray-50 rounded-lg">
                <div className="w-32">
                  <span className="font-medium text-gray-900">{dayNames[day as keyof typeof dayNames]}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    checked={schedule.isOpen}
                    onCheckedChange={(checked) => handleWorkingHoursChange(day as keyof typeof companyData.workingHours, 'isOpen', checked as boolean)}
                  />
                  <span className="text-sm text-gray-600">Aberto</span>
                </div>
                {schedule.isOpen && (
                  <>
                    <div className="flex items-center space-x-2">
                      <Label htmlFor={`${day}-start`} className="text-sm">De:</Label>
                      <Input
                        id={`${day}-start`}
                        type="time"
                        value={schedule.start}
                        onChange={(e) => handleWorkingHoursChange(day as keyof typeof companyData.workingHours, 'start', e.target.value)}
                        className="w-24"
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <Label htmlFor={`${day}-end`} className="text-sm">Até:</Label>
                      <Input
                        id={`${day}-end`}
                        type="time"
                        value={schedule.end}
                        onChange={(e) => handleWorkingHoursChange(day as keyof typeof companyData.workingHours, 'end', e.target.value)}
                        className="w-24"
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        checked={schedule.hasLunchBreak}
                        onCheckedChange={(checked) => handleWorkingHoursChange(day as keyof typeof companyData.workingHours, 'hasLunchBreak', checked as boolean)}
                      />
                      <span className="text-sm text-gray-600">Almoço</span>
                    </div>
                    {schedule.hasLunchBreak && (
                      <>
                        <div className="flex items-center space-x-2">
                          <Label htmlFor={`${day}-lunch-start`} className="text-sm">De:</Label>
                          <Input
                            id={`${day}-lunch-start`}
                            type="time"
                            value={schedule.lunchStart}
                            onChange={(e) => handleWorkingHoursChange(day as keyof typeof companyData.workingHours, 'lunchStart', e.target.value)}
                            className="w-24"
                            placeholder="--:--"
                          />
                        </div>
                        <div className="flex items-center space-x-2">
                          <Label htmlFor={`${day}-lunch-end`} className="text-sm">Até:</Label>
                          <Input
                            id={`${day}-lunch-end`}
                            type="time"
                            value={schedule.lunchEnd}
                            onChange={(e) => handleWorkingHoursChange(day as keyof typeof companyData.workingHours, 'lunchEnd', e.target.value)}
                            className="w-24"
                            placeholder="--:--"
                          />
                        </div>
                      </>
                    )}
                  </>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Botão Salvar */}
      <div className="flex justify-end">
        <Button 
          onClick={handleSave}
          className="bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white px-6 py-3 rounded-xl"
        >
          <Save className="h-5 w-5 mr-2" />
          Salvar Dados da Empresa
        </Button>
      </div>
    </div>
  );
};

export default CompanyDataManager;

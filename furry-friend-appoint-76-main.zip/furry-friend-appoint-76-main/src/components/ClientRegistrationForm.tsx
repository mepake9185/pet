
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import AddressForm from "@/components/forms/AddressForm";
import PetManagement from "@/components/forms/PetManagement";
import { useFormValidation } from "@/hooks/useFormValidation";

interface Pet {
  name: string;
  breed: string;
}

interface Client {
  id?: number;
  name: string;
  email: string;
  phone: string;
  cep: string;
  address: string;
  addressNumber: string;
  complement: string;
  neighborhood: string;
  city: string;
  state: string;
  pets: Pet[];
}

interface ClientRegistrationFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (clientData: Client) => void;
  editingClient?: Client;
  isEditing?: boolean;
}

const ClientRegistrationForm = ({ 
  open, 
  onOpenChange, 
  onSubmit, 
  editingClient,
  isEditing = false 
}: ClientRegistrationFormProps) => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    cep: "",
    address: "",
    addressNumber: "",
    complement: "",
    neighborhood: "",
    city: "",
    state: "",
  });

  const [pets, setPets] = useState<Pet[]>([{ name: "", breed: "" }]);
  const { formatPhone, validateForm } = useFormValidation();

  // Effect to populate form when editing
  useEffect(() => {
    if (isEditing && editingClient) {
      setFormData({
        name: editingClient.name,
        email: editingClient.email,
        phone: editingClient.phone,
        cep: editingClient.cep,
        address: editingClient.address,
        addressNumber: editingClient.addressNumber,
        complement: editingClient.complement,
        neighborhood: editingClient.neighborhood,
        city: editingClient.city,
        state: editingClient.state,
      });
      setPets(editingClient.pets);
    } else {
      // Reset form for new client
      setFormData({
        name: "",
        email: "",
        phone: "",
        cep: "",
        address: "",
        addressNumber: "",
        complement: "",
        neighborhood: "",
        city: "",
        state: "",
      });
      setPets([{ name: "", breed: "" }]);
    }
  }, [isEditing, editingClient, open]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm(formData, pets)) {
      return;
    }

    const clientData: Client = {
      ...formData,
      pets: pets
    };

    if (isEditing && editingClient) {
      clientData.id = editingClient.id;
    }

    onSubmit(clientData);
    
    // Reset form only if not editing (editing will be handled by parent)
    if (!isEditing) {
      setFormData({
        name: "",
        email: "",
        phone: "",
        cep: "",
        address: "",
        addressNumber: "",
        complement: "",
        neighborhood: "",
        city: "",
        state: "",
      });
      setPets([{ name: "", breed: "" }]);
    }
    onOpenChange(false);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handlePhoneChange = (value: string) => {
    const formattedPhone = formatPhone(value);
    handleInputChange("phone", formattedPhone);
  };

  const handlePetChange = (index: number, field: string, value: string) => {
    setPets(prev => prev.map((pet, i) => 
      i === index ? { ...pet, [field]: value } : pet
    ));
  };

  const addPet = () => {
    setPets(prev => [...prev, { name: "", breed: "" }]);
  };

  const removePet = (index: number) => {
    if (pets.length > 1) {
      setPets(prev => prev.filter((_, i) => i !== index));
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEditing ? "Editar Cliente" : "Cadastrar Cliente"}</DialogTitle>
          <DialogDescription>
            {isEditing 
              ? "Edite os dados do cliente e seus pets." 
              : "Preencha os dados do cliente e seus pets para cadastro no sistema."
            }
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Nome do Cliente</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => handleInputChange("name", e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => handleInputChange("email", e.target.value)}
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="phone">Telefone Celular</Label>
            <Input
              id="phone"
              type="tel"
              value={formData.phone}
              onChange={(e) => handlePhoneChange(e.target.value)}
              placeholder="(11) 99999-9999"
              maxLength={15}
              required
            />
          </div>

          <AddressForm 
            formData={formData}
            onInputChange={handleInputChange}
          />
          
          <PetManagement 
            pets={pets}
            onPetChange={handlePetChange}
            onAddPet={addPet}
            onRemovePet={removePet}
          />
          
          <DialogFooter className="gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit">
              {isEditing ? "Salvar Alterações" : "Cadastrar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ClientRegistrationForm;

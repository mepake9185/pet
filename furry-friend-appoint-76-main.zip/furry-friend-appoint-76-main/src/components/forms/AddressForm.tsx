
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface AddressData {
  cep: string;
  address: string;
  addressNumber: string;
  complement: string;
  neighborhood: string;
  city: string;
  state: string;
}

interface AddressFormProps {
  formData: AddressData;
  onInputChange: (field: string, value: string) => void;
}

const AddressForm = ({ formData, onInputChange }: AddressFormProps) => {
  const [isLoadingCep, setIsLoadingCep] = useState(false);
  const [cepError, setCepError] = useState("");
  const { toast } = useToast();

  const handleCepChange = async (cep: string) => {
    // Remove non-numeric characters
    const cleanCep = cep.replace(/\D/g, '');
    
    // Format CEP with dash
    let formattedCep = cleanCep;
    if (cleanCep.length > 5) {
      formattedCep = `${cleanCep.slice(0, 5)}-${cleanCep.slice(5, 8)}`;
    }
    
    onInputChange("cep", formattedCep);
    setCepError("");

    // If CEP is complete (8 digits), fetch address
    if (cleanCep.length === 8) {
      setIsLoadingCep(true);
      try {
        const response = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`);
        
        if (!response.ok) {
          throw new Error("Erro na consulta do CEP");
        }
        
        const data = await response.json();
        
        if (data.erro) {
          setCepError("CEP não encontrado");
          toast({
            title: "CEP não encontrado",
            description: "Por favor, verifique o CEP digitado.",
            variant: "destructive",
          });
        } else {
          onInputChange("address", data.logradouro || "");
          onInputChange("neighborhood", data.bairro || "");
          onInputChange("city", data.localidade || "");
          onInputChange("state", data.uf || "");
          
          toast({
            title: "Endereço encontrado!",
            description: "Os dados do endereço foram preenchidos automaticamente.",
          });
        }
      } catch (error) {
        console.error("Erro ao buscar CEP:", error);
        setCepError("Erro ao buscar CEP. Tente novamente.");
        toast({
          title: "Erro na consulta",
          description: "Não foi possível consultar o CEP. Preencha o endereço manualmente.",
          variant: "destructive",
        });
      } finally {
        setIsLoadingCep(false);
      }
    }
  };

  return (
    <>
      <div className="space-y-2">
        <Label htmlFor="cep">CEP</Label>
        <Input
          id="cep"
          value={formData.cep}
          onChange={(e) => handleCepChange(e.target.value)}
          placeholder="00000-000"
          maxLength={9}
          required
          className={cepError ? "border-red-500" : ""}
        />
        {isLoadingCep && (
          <p className="text-sm text-blue-600">Buscando endereço...</p>
        )}
        {cepError && (
          <div className="flex items-center text-sm text-red-600">
            <AlertCircle className="h-4 w-4 mr-1" />
            {cepError}
          </div>
        )}
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="address">Logradouro</Label>
        <Input
          id="address"
          value={formData.address}
          onChange={(e) => onInputChange("address", e.target.value)}
          required
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="addressNumber">Número</Label>
          <Input
            id="addressNumber"
            value={formData.addressNumber}
            onChange={(e) => onInputChange("addressNumber", e.target.value)}
            required
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="complement">Complemento</Label>
          <Input
            id="complement"
            value={formData.complement}
            onChange={(e) => onInputChange("complement", e.target.value)}
            placeholder="Opcional"
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="neighborhood">Bairro</Label>
        <Input
          id="neighborhood"
          value={formData.neighborhood}
          onChange={(e) => onInputChange("neighborhood", e.target.value)}
          required
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="city">Cidade</Label>
          <Input
            id="city"
            value={formData.city}
            onChange={(e) => onInputChange("city", e.target.value)}
            required
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="state">Estado</Label>
          <Input
            id="state"
            value={formData.state}
            onChange={(e) => onInputChange("state", e.target.value)}
            maxLength={2}
            placeholder="SP"
            required
          />
        </div>
      </div>
    </>
  );
};

export default AddressForm;


import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import DogBreedSelect from "@/components/ui/DogBreedSelect";
import { Plus, X } from "lucide-react";

interface Pet {
  name: string;
  breed: string;
}

interface PetManagementProps {
  pets: Pet[];
  onPetChange: (index: number, field: string, value: string) => void;
  onAddPet: () => void;
  onRemovePet: (index: number) => void;
}

const PetManagement = ({ pets, onPetChange, onAddPet, onRemovePet }: PetManagementProps) => {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Label className="text-base font-semibold">Pets</Label>
      </div>
      
      {pets.map((pet, index) => (
        <div key={index} className="border rounded-lg p-4 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-medium">Pet {index + 1}</h4>
            {pets.length > 1 && (
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => onRemovePet(index)}
                className="text-red-600 hover:text-red-700"
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor={`petName-${index}`}>Nome do Pet</Label>
              <Input
                id={`petName-${index}`}
                value={pet.name}
                onChange={(e) => onPetChange(index, "name", e.target.value)}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor={`petBreed-${index}`}>Raça</Label>
              <DogBreedSelect
                value={pet.breed}
                onValueChange={(value) => onPetChange(index, "breed", value)}
              />
            </div>
          </div>
        </div>
      ))}
      
      <div className="flex justify-center">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={onAddPet}
          className="flex items-center gap-2"
        >
          <Plus className="h-4 w-4" />
          + 1 Pet
        </Button>
      </div>
    </div>
  );
};

export default PetManagement;

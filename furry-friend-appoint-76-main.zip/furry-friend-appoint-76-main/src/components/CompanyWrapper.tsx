
import { useEffect, useState } from "react";
import { useCompanySlug } from "@/hooks/useCompanySlug";
import { useCompanyRegistry } from "@/contexts/CompanyRegistryContext";
import { useCompanyData } from "@/contexts/CompanyDataContext";
import { useClients } from "@/contexts/ClientContext";
import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

interface CompanyWrapperProps {
  children: React.ReactNode;
}

const CompanyWrapper = ({ children }: CompanyWrapperProps) => {
  const { slug, isValidSlug, normalizedSlug } = useCompanySlug();
  const { getCompanyBySlug } = useCompanyRegistry();
  const { loadCompanyDataBySlug } = useCompanyData();
  const { setCurrentCompanySlug } = useClients();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [companyExists, setCompanyExists] = useState(false);

  useEffect(() => {
    if (slug && isValidSlug) {
      const company = getCompanyBySlug(normalizedSlug);
      if (company) {
        setCompanyExists(true);
        loadCompanyDataBySlug(normalizedSlug);
        setCurrentCompanySlug(normalizedSlug);
      } else {
        setCompanyExists(false);
      }
    }
    setIsLoading(false);
  }, [slug, isValidSlug, normalizedSlug, getCompanyBySlug, loadCompanyDataBySlug, setCurrentCompanySlug]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  if (slug && !companyExists) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center p-4">
        <Card className="max-w-md w-full border-0 shadow-xl bg-white/90 backdrop-blur-sm">
          <CardContent className="p-8 text-center">
            <div className="bg-red-100 p-3 rounded-2xl w-fit mx-auto mb-4">
              <AlertCircle className="h-8 w-8 text-red-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Empresa não encontrada</h2>
            <p className="text-gray-600 mb-6">
              A empresa "{slug}" não foi encontrada no sistema ou está inativa.
            </p>
            <Button 
              onClick={() => navigate('/')}
              className="w-full bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white"
            >
              Voltar ao início
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return <>{children}</>;
};

export default CompanyWrapper;

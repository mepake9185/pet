
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  BarChart3, 
  Calendar, 
  Users, 
  Scissors, 
  Settings, 
  PawPrint,
  DollarSign,
  Clock,
  Phone,
  Menu,
  X,
  Plus,
  MapPin,
  Edit,
  ChevronDown,
  ChevronRight,
  Car,
  Mail
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import AppointmentCalendar from "@/components/AppointmentCalendar";
import ClientRegistrationForm from "@/components/ClientRegistrationForm";
import { useToast } from "@/hooks/use-toast";
import DogBreedManager from "@/components/DogBreedManager";
import PetShopServiceManager from "@/components/PetShopServiceManager";
import TaxiDogServiceManager from "@/components/TaxiDogServiceManager";
import CompanyDataManager from "@/components/CompanyDataManager";
import { useClients } from "@/contexts/ClientContext";

interface Pet {
  name: string;
  breed: string;
}

interface Client {
  id: number;
  name: string;
  phone: string;
  cep: string;
  address: string;
  addressNumber: string;
  complement: string;
  neighborhood: string;
  city: string;
  state: string;
  pets: Pet[];
  email: string;
}

const menuItems = [
  { title: "Dashboard", icon: BarChart3, id: "dashboard" },
  { title: "Agendamentos", icon: Calendar, id: "appointments" },
  { title: "Clientes", icon: Users, id: "clients" },
  { 
    title: "Serviços", 
    icon: Scissors, 
    id: "services",
    submenu: [
      { title: "Serviços pet shop", id: "petshop-services" },
      { title: "Serviços táxi dog", id: "taxi-dog-services" }
    ]
  },
  { 
    title: "Gerenciamento", 
    icon: Settings, 
    id: "management",
    submenu: [
      { title: "Dados da empresa", id: "company-data" },
      { title: "Raças de Cachorro", id: "dog-breeds" }
    ]
  },
  { title: "Configurações", icon: Settings, id: "settings" },
];

const PetshopSidebar = ({ activeSection, setActiveSection }: { activeSection: string, setActiveSection: (section: string) => void }) => {
  const [expandedMenus, setExpandedMenus] = useState<string[]>([]);

  const toggleSubmenu = (menuId: string) => {
    setExpandedMenus(prev => 
      prev.includes(menuId) 
        ? prev.filter(id => id !== menuId)
        : [...prev, menuId]
    );
  };

  const isExpanded = (menuId: string) => expandedMenus.includes(menuId);

  return (
    <Sidebar collapsible="icon">
      <SidebarContent className="bg-gradient-to-b from-indigo-600 to-indigo-800">
        <div className="p-4">
          <div className="flex items-center mb-8">
            <div className="bg-white p-2 rounded-xl mr-3">
              <PawPrint className="h-6 w-6 text-indigo-600" />
            </div>
            <div>
              <h2 className="text-white font-bold text-lg">PetSchedule</h2>
              <p className="text-indigo-200 text-sm">Admin</p>
            </div>
          </div>
        </div>

        <SidebarGroup>
          <SidebarGroupLabel className="text-indigo-200 px-4">Menu Principal</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  {item.submenu ? (
                    <>
                      <SidebarMenuButton 
                        onClick={() => toggleSubmenu(item.id)}
                        className={`mx-2 rounded-xl transition-all duration-200 text-white hover:bg-indigo-500/50`}
                      >
                        <item.icon className="h-5 w-5" />
                        <span className="font-medium">{item.title}</span>
                        {isExpanded(item.id) ? (
                          <ChevronDown className="h-4 w-4 ml-auto" />
                        ) : (
                          <ChevronRight className="h-4 w-4 ml-auto" />
                        )}
                      </SidebarMenuButton>
                      {isExpanded(item.id) && (
                        <div className="ml-6 mt-2 space-y-1">
                          {item.submenu.map((subItem) => (
                            <SidebarMenuButton
                              key={subItem.id}
                              onClick={() => setActiveSection(subItem.id)}
                              className={`mx-2 rounded-xl transition-all duration-200 ${
                                activeSection === subItem.id
                                  ? "bg-white text-indigo-600 shadow-lg"
                                  : "text-white hover:bg-indigo-500/50"
                              }`}
                            >
                              <PawPrint className="h-4 w-4" />
                              <span className="font-medium">{subItem.title}</span>
                            </SidebarMenuButton>
                          ))}
                        </div>
                      )}
                    </>
                  ) : (
                    <SidebarMenuButton 
                      onClick={() => setActiveSection(item.id)}
                      className={`mx-2 rounded-xl transition-all duration-200 ${
                        activeSection === item.id
                          ? "bg-white text-indigo-600 shadow-lg"
                          : "text-white hover:bg-indigo-500/50"
                      }`}
                    >
                      <item.icon className="h-5 w-5" />
                      <span className="font-medium">{item.title}</span>
                    </SidebarMenuButton>
                  )}
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
};

const DashboardContent = () => {
  const stats = [
    { title: "Agendamentos Hoje", value: "8", icon: Calendar, color: "bg-blue-500" },
    { title: "Clientes Ativos", value: "156", icon: Users, color: "bg-green-500" },
    { title: "Receita Mensal", value: "R$ 12.450", icon: DollarSign, color: "bg-purple-500" },
  ];

  const todayAppointments = [
    { id: 1, time: "09:00", client: "Maria Silva", pet: "Rex", service: "Banho e Tosa", status: "confirmed" },
    { id: 2, time: "10:30", client: "João Santos", pet: "Luna", service: "Banho", status: "pending" },
    { id: 3, time: "14:00", client: "Ana Costa", pet: "Max", service: "Tosa", status: "confirmed" },
    { id: 4, time: "15:30", client: "Pedro Lima", pet: "Bella", service: "Banho e Tosa", status: "confirmed" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Dashboard</h1>
        <p className="text-gray-600">Visão geral do seu petshop</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <Card key={stat.title} className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">{stat.title}</p>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                </div>
                <div className={`${stat.color} p-3 rounded-xl`}>
                  <stat.icon className="h-6 w-6 text-white" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Today's Appointments */}
      <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Calendar className="h-5 w-5 mr-2 text-indigo-600" />
            Agendamentos de Hoje
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {todayAppointments.map((appointment) => (
              <div key={appointment.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                <div className="flex items-center space-x-4">
                  <div className="bg-indigo-100 p-2 rounded-lg">
                    <Clock className="h-4 w-4 text-indigo-600" />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{appointment.time}</p>
                    <p className="text-sm text-gray-600">{appointment.client} - {appointment.pet}</p>
                    <p className="text-sm text-gray-500">{appointment.service}</p>
                  </div>
                </div>
                <Badge 
                  className={
                    appointment.status === "confirmed" 
                      ? "bg-green-100 text-green-800" 
                      : "bg-yellow-100 text-yellow-800"
                  }
                >
                  {appointment.status === "confirmed" ? "Confirmado" : "Pendente"}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

const AppointmentsContent = () => <AppointmentCalendar />;

const ClientsContent = () => {
  const [isRegistrationOpen, setIsRegistrationOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<any>(undefined);
  const [isEditing, setIsEditing] = useState(false);
  const { clients, addClient, updateClient } = useClients();
  const { toast } = useToast();

  const formatPhoneForDisplay = (phone: string) => {
    // Remove all non-numeric characters
    const cleanPhone = phone.replace(/\D/g, '');
    
    // If phone is already in correct format, return as is
    if (phone.includes('(') && phone.includes(')') && phone.includes('-')) {
      return phone;
    }
    
    // Format to (11) 99999-9999
    if (cleanPhone.length === 11) {
      return `(${cleanPhone.slice(0, 2)}) ${cleanPhone.slice(2, 7)}-${cleanPhone.slice(7)}`;
    }
    
    return phone; // Return original if can't format
  };

  const handleClientRegistration = (clientData: any) => {
    if (isEditing && editingClient) {
      // Update existing client
      const updatedClient = {
        ...clientData,
        id: editingClient.id,
        phone: formatPhoneForDisplay(clientData.phone)
      };
      updateClient(updatedClient);
      
      toast({
        title: "Cliente atualizado com sucesso!",
        description: `${clientData.name} foi atualizado no sistema.`,
      });
      
      setIsEditing(false);
      setEditingClient(undefined);
    } else {
      // Add new client
      const newClientData = {
        ...clientData,
        phone: formatPhoneForDisplay(clientData.phone)
      };
      addClient(newClientData);
      
      toast({
        title: "Cliente cadastrado com sucesso!",
        description: `${clientData.name} foi adicionado ao sistema.`,
      });
    }
  };

  const handleEditClient = (client: any) => {
    setEditingClient(client);
    setIsEditing(true);
    setIsRegistrationOpen(true);
  };

  const handleCloseDialog = () => {
    setIsRegistrationOpen(false);
    setIsEditing(false);
    setEditingClient(undefined);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Clientes</h1>
        <Button 
          onClick={() => setIsRegistrationOpen(true)}
          className="bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white px-6 py-3 rounded-xl"
        >
          <Plus className="h-5 w-5 mr-2" />
          Cadastrar Cliente
        </Button>
      </div>

      <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
        <CardContent className="p-6">
          <div className="space-y-4">
            {clients.map((client) => (
              <div key={client.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                <div className="flex items-center space-x-4">
                  <div className="bg-indigo-100 p-3 rounded-xl">
                    <Users className="h-6 w-6 text-indigo-600" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900">{client.name}</h3>
                    <div className="flex items-center text-sm text-gray-600 mt-1">
                      <Phone className="h-4 w-4 mr-1" />
                      {formatPhoneForDisplay(client.phone)}
                    </div>
                    <div className="flex items-center text-sm text-gray-600 mt-1">
                      <Mail className="h-4 w-4 mr-1" />
                      {client.email}
                    </div>
                    <div className="flex items-center text-sm text-gray-600 mt-1">
                      <MapPin className="h-4 w-4 mr-1" />
                      {client.address}, {client.addressNumber} - {client.neighborhood}, {client.city}/{client.state}
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <div className="space-y-1">
                      {client.pets.map((pet, index) => (
                        <div key={index} className="flex items-center justify-end">
                          <PawPrint className="h-4 w-4 mr-1 text-indigo-600" />
                          <span className="font-medium text-gray-900 mr-2">{pet.name}</span>
                          <span className="text-sm text-gray-600">({pet.breed})</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEditClient(client)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <ClientRegistrationForm
        open={isRegistrationOpen}
        onOpenChange={handleCloseDialog}
        onSubmit={handleClientRegistration}
        editingClient={editingClient}
        isEditing={isEditing}
      />
    </div>
  );
};

const ServicesContent = () => (
  <div className="space-y-6">
    <h1 className="text-3xl font-bold text-gray-900">Serviços</h1>
    <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
      <CardContent className="p-6">
        <p className="text-gray-600">Configurações de serviços em desenvolvimento...</p>
      </CardContent>
    </Card>
  </div>
);

const PetShopServicesContent = () => (
  <div className="space-y-6">
    <h1 className="text-3xl font-bold text-gray-900">Serviços Pet Shop</h1>
    <PetShopServiceManager />
  </div>
);

const TaxiDogServicesContent = () => (
  <div className="space-y-6">
    <h1 className="text-3xl font-bold text-gray-900">Serviços Táxi Dog</h1>
    <TaxiDogServiceManager />
  </div>
);

const DogBreedsContent = () => (
  <div className="space-y-6">
    <h1 className="text-3xl font-bold text-gray-900">Raças de Cachorro</h1>
    <DogBreedManager />
  </div>
);

const SettingsContent = () => (
  <div className="space-y-6">
    <h1 className="text-3xl font-bold text-gray-900">Configurações</h1>
    <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
      <CardContent className="p-6">
        <p className="text-gray-600">Configurações do sistema em desenvolvimento...</p>
      </CardContent>
    </Card>
  </div>
);

const CompanyDataContent = () => (
  <div className="space-y-6">
    <h1 className="text-3xl font-bold text-gray-900">Dados da Empresa</h1>
    <CompanyDataManager />
  </div>
);

const PetshopDashboard = () => {
  const [activeSection, setActiveSection] = useState("dashboard");

  const renderContent = () => {
    switch (activeSection) {
      case "dashboard":
        return <DashboardContent />;
      case "appointments":
        return <AppointmentsContent />;
      case "clients":
        return <ClientsContent />;
      case "services":
        return <ServicesContent />;
      case "petshop-services":
        return <PetShopServicesContent />;
      case "taxi-dog-services":
        return <TaxiDogServicesContent />;
      case "dog-breeds":
        return <DogBreedsContent />;
      case "company-data":
        return <CompanyDataContent />;
      case "settings":
        return <SettingsContent />;
      default:
        return <DashboardContent />;
    }
  };

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-gradient-to-br from-blue-50 via-white to-indigo-50">
        <PetshopSidebar activeSection={activeSection} setActiveSection={setActiveSection} />
        
        <main className="flex-1">
          {/* Header */}
          <div className="bg-white/80 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-10">
            <div className="px-6 py-4">
              <div className="flex items-center justify-between">
                <SidebarTrigger className="lg:hidden" />
                <div className="flex items-center space-x-4 ml-auto">
                  <span className="text-gray-700 font-medium">Pet Shop Exemplo</span>
                  <div className="w-8 h-8 bg-gradient-to-r from-indigo-500 to-indigo-600 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-medium">PS</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="p-6">
            {renderContent()}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
};

export default PetshopDashboard;

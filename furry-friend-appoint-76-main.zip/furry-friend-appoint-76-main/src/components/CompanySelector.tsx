
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Building2, ArrowRight } from "lucide-react";
import { useCompanyRegistry } from "@/contexts/CompanyRegistryContext";
import { useNavigate } from "react-router-dom";

const CompanySelector = () => {
  const { companies } = useCompanyRegistry();
  const navigate = useNavigate();

  const handleCompanySelect = (slug: string) => {
    navigate(`/${slug}`);
  };

  const activeCompanies = companies.filter(company => company.isActive);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        <div className="text-center mb-12">
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-3 rounded-2xl w-fit mx-auto mb-4">
            <Building2 className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Selecione a Empresa</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Escolha a empresa para acessar os serviços de agendamento.
          </p>
        </div>

        <div className="grid gap-6 max-w-2xl mx-auto">
          {activeCompanies.map((company) => (
            <Card 
              key={company.id}
              className="group cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-1 border-0 shadow-lg bg-white/80 backdrop-blur-sm"
              onClick={() => handleCompanySelect(company.slug)}
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="bg-gradient-to-r from-indigo-500 to-indigo-600 p-3 rounded-xl">
                      <Building2 className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900">{company.name}</h3>
                      <p className="text-gray-600">{company.email}</p>
                      <p className="text-sm text-gray-500">{company.phone}</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" className="group-hover:bg-indigo-50">
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {activeCompanies.length === 0 && (
          <div className="text-center">
            <p className="text-gray-500">Nenhuma empresa cadastrada no sistema.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CompanySelector;

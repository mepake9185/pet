
import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useCompanyData } from "@/contexts/CompanyDataContext";
import { Car } from "lucide-react";

const TaxiDogServiceManager = () => {
  const [isEnabled, setIsEnabled] = useState(false);
  const [cidade, setCidade] = useState("");
  const [bairro, setBairro] = useState("");
  const { companyData } = useCompanyData();
  const { toast } = useToast();

  useEffect(() => {
    // Carregar dados salvos do localStorage
    const savedData = localStorage.getItem('taxi-dog-service');
    if (savedData) {
      try {
        const data = JSON.parse(savedData);
        setIsEnabled(data.isEnabled || false);
        setCidade(data.cidade || "");
        setBairro(data.bairro || "");
      } catch (error) {
        console.error('Error loading taxi dog service data:', error);
      }
    }
  }, []);

  const saveData = () => {
    const dataToSave = {
      isEnabled,
      cidade,
      bairro
    };
    localStorage.setItem('taxi-dog-service', JSON.stringify(dataToSave));
  };

  const handleToggleService = (enabled: boolean) => {
    setIsEnabled(enabled);
  };

  const handleSave = () => {
    saveData();
    toast({
      title: "Configurações salvas!",
      description: "As configurações do serviço Táxi Dog foram salvas com sucesso.",
    });
  };

  return (
    <div className="space-y-6">
      <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Car className="h-5 w-5 mr-2 text-indigo-600" />
            Configurações do Serviço Táxi Dog
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label className="text-base font-medium">Habilitar Serviço Táxi Dog</Label>
              <p className="text-sm text-gray-600">
                Ative ou desative o serviço de transporte para pets
              </p>
            </div>
            <Switch
              checked={isEnabled}
              onCheckedChange={handleToggleService}
            />
          </div>

          {isEnabled && (
            <div className="space-y-4 pt-4 border-t">
              <div className="space-y-2">
                <Label htmlFor="cidade" className="text-base font-medium">Cidade</Label>
                <Input
                  id="cidade"
                  type="text"
                  value={cidade}
                  onChange={(e) => setCidade(e.target.value)}
                  placeholder="Digite a cidade"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="bairro" className="text-base font-medium">Bairro</Label>
                <Input
                  id="bairro"
                  type="text"
                  value={bairro}
                  onChange={(e) => setBairro(e.target.value)}
                  placeholder="Digite o bairro"
                />
              </div>
            </div>
          )}

          <div className="flex justify-end pt-6 border-t">
            <Button 
              onClick={handleSave}
              className="bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800"
            >
              Salvar Configurações
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TaxiDogServiceManager;

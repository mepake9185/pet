import { useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Plus, Edit, Trash2, PawPrint, Settings, MoreVertical, ArrowUpDown, Search, X } from "lucide-react";
import { useDogBreeds } from "@/contexts/DogBreedContext";
import { useToast } from "@/hooks/use-toast";

interface BreedWithSize {
  name: string;
  size: string;
}

const DogBreedManager = () => {
  const { breeds, addBreed, updateBreed, deleteBreed } = useDogBreeds();
  const { toast } = useToast();
  
  // Breeds with sizes
  const [breedsWithSizes, setBreedsWithSizes] = useState<BreedWithSize[]>(
    breeds.map(breed => ({ name: breed, size: "Médio" }))
  );
  
  // Search functionality
  const [searchTerm, setSearchTerm] = useState("");
  const [highlightedBreed, setHighlightedBreed] = useState<string>("");
  const tableBodyRef = useRef<HTMLTableSectionElement>(null);
  
  // Sorting state
  const [sortBy, setSortBy] = useState<'name' | 'size' | null>(null);
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  
  // Size options management
  const [sizeOptions, setSizeOptions] = useState<string[]>(["Pequeno", "Médio", "Grande", "Gigante"]);
  const [isSizeManagerOpen, setIsSizeManagerOpen] = useState(false);
  const [newSizeOption, setNewSizeOption] = useState("");
  const [editingSizeOption, setEditingSizeOption] = useState("");
  const [editSizeOptionName, setEditSizeOptionName] = useState("");
  const [isEditSizeDialogOpen, setIsEditSizeDialogOpen] = useState(false);
  
  // Breed management dialogs
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [newBreedName, setNewBreedName] = useState("");
  const [newBreedSize, setNewBreedSize] = useState("Médio");
  const [editingBreed, setEditingBreed] = useState<string>("");
  const [editBreedName, setEditBreedName] = useState("");
  const [editBreedSize, setEditBreedSize] = useState("");
  const [deletingBreed, setDeletingBreed] = useState<string>("");

  // Filter breeds based on search term
  const filteredBreeds = breedsWithSizes.filter(breed =>
    breed.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const scrollToBreed = (breedName: string) => {
    const rowElement = document.querySelector(`[data-breed-name="${breedName}"]`);
    if (rowElement) {
      rowElement.scrollIntoView({ 
        behavior: 'smooth', 
        block: 'center' 
      });
      setHighlightedBreed(breedName);
      // Remove highlight after 2 seconds
      setTimeout(() => setHighlightedBreed(""), 2000);
    }
  };

  const handleSearch = (value: string) => {
    setSearchTerm(value);
    if (value.trim()) {
      const matchedBreed = breedsWithSizes.find(breed =>
        breed.name.toLowerCase().includes(value.toLowerCase())
      );
      if (matchedBreed) {
        scrollToBreed(matchedBreed.name);
      }
    }
  };

  const clearSearch = () => {
    setSearchTerm("");
    setHighlightedBreed("");
  };

  // Sorting function
  const handleSort = (column: 'name' | 'size') => {
    let newOrder: 'asc' | 'desc' = 'asc';
    
    if (sortBy === column && sortOrder === 'asc') {
      newOrder = 'desc';
    }
    
    setSortBy(column);
    setSortOrder(newOrder);
    
    const sorted = [...breedsWithSizes].sort((a, b) => {
      const aValue = column === 'name' ? a.name : a.size;
      const bValue = column === 'name' ? b.name : b.size;
      
      if (newOrder === 'asc') {
        return aValue.localeCompare(bValue, 'pt-BR');
      } else {
        return bValue.localeCompare(aValue, 'pt-BR');
      }
    });
    
    setBreedsWithSizes(sorted);
  };

  const handleAddBreed = () => {
    if (newBreedName.trim()) {
      if (breeds.includes(newBreedName.trim())) {
        toast({
          title: "Erro",
          description: "Esta raça já existe na lista.",
          variant: "destructive",
        });
        return;
      }
      
      addBreed(newBreedName);
      setBreedsWithSizes(prev => [...prev, { name: newBreedName, size: newBreedSize }]);
      toast({
        title: "Raça adicionada!",
        description: `${newBreedName} foi adicionada com sucesso.`,
      });
      setNewBreedName("");
      setNewBreedSize("Médio");
      setIsAddDialogOpen(false);
    }
  };

  const handleEditBreed = () => {
    if (editBreedName.trim() && editingBreed) {
      if (breeds.includes(editBreedName.trim()) && editBreedName.trim() !== editingBreed) {
        toast({
          title: "Erro",
          description: "Esta raça já existe na lista.",
          variant: "destructive",
        });
        return;
      }
      
      updateBreed(editingBreed, editBreedName);
      setBreedsWithSizes(prev => prev.map(breed => 
        breed.name === editingBreed 
          ? { name: editBreedName, size: editBreedSize }
          : breed
      ));
      toast({
        title: "Raça atualizada!",
        description: `Raça atualizada para ${editBreedName} com sucesso.`,
      });
      setEditingBreed("");
      setEditBreedName("");
      setEditBreedSize("");
      setIsEditDialogOpen(false);
    }
  };

  const handleDeleteBreed = () => {
    if (deletingBreed) {
      deleteBreed(deletingBreed);
      setBreedsWithSizes(prev => prev.filter(breed => breed.name !== deletingBreed));
      toast({
        title: "Raça removida!",
        description: `${deletingBreed} foi removida com sucesso.`,
      });
      setDeletingBreed("");
      setIsDeleteDialogOpen(false);
    }
  };

  const handleSizeChange = (breedName: string, newSize: string) => {
    setBreedsWithSizes(prev => prev.map(breed => 
      breed.name === breedName 
        ? { ...breed, size: newSize }
        : breed
    ));
  };

  const handleAddSizeOption = () => {
    if (newSizeOption.trim() && !sizeOptions.includes(newSizeOption.trim())) {
      setSizeOptions(prev => [...prev, newSizeOption.trim()]);
      setNewSizeOption("");
      toast({
        title: "Porte adicionado!",
        description: `${newSizeOption} foi adicionado às opções.`,
      });
    }
  };

  const handleEditSizeOption = () => {
    if (editSizeOptionName.trim() && editingSizeOption) {
      setSizeOptions(prev => prev.map(option => 
        option === editingSizeOption ? editSizeOptionName.trim() : option
      ));
      // Update breeds that use this size option
      setBreedsWithSizes(prev => prev.map(breed => 
        breed.size === editingSizeOption 
          ? { ...breed, size: editSizeOptionName.trim() }
          : breed
      ));
      setEditingSizeOption("");
      setEditSizeOptionName("");
      setIsEditSizeDialogOpen(false);
      toast({
        title: "Porte atualizado!",
        description: `Porte atualizado com sucesso.`,
      });
    }
  };

  const handleDeleteSizeOption = (optionToDelete: string) => {
    setSizeOptions(prev => prev.filter(option => option !== optionToDelete));
    // Reset breeds with this size to "Médio"
    setBreedsWithSizes(prev => prev.map(breed => 
      breed.size === optionToDelete 
        ? { ...breed, size: "Médio" }
        : breed
    ));
    toast({
      title: "Porte removido!",
      description: `${optionToDelete} foi removido das opções.`,
    });
  };

  const openEditDialog = (breed: string) => {
    const breedWithSize = breedsWithSizes.find(b => b.name === breed);
    setEditingBreed(breed);
    setEditBreedName(breed);
    setEditBreedSize(breedWithSize?.size || "Médio");
    setIsEditDialogOpen(true);
  };

  const openDeleteDialog = (breed: string) => {
    setDeletingBreed(breed);
    setIsDeleteDialogOpen(true);
  };

  const openEditSizeDialog = (sizeOption: string) => {
    setEditingSizeOption(sizeOption);
    setEditSizeOptionName(sizeOption);
    setIsEditSizeDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <PawPrint className="h-6 w-6 mr-2 text-indigo-600" />
              <CardTitle>Gerenciar Raças de Cachorro</CardTitle>
            </div>
            <div className="flex space-x-2">
              <Button
                variant="outline"
                onClick={() => setIsSizeManagerOpen(true)}
                className="text-gray-600 hover:text-gray-700"
              >
                <Settings className="h-4 w-4 mr-2" />
                Gerenciar Portes
              </Button>
              <Button 
                onClick={() => setIsAddDialogOpen(true)}
                className="bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white"
              >
                <Plus className="h-4 w-4 mr-2" />
                Adicionar Raça
              </Button>
            </div>
          </div>
          
          {/* Search Filter */}
          <div className="flex items-center space-x-2 mt-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Buscar raça..."
                value={searchTerm}
                onChange={(e) => handleSearch(e.target.value)}
                className="pl-10 pr-10"
              />
              {searchTerm && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={clearSearch}
                  className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0"
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
            {searchTerm && (
              <div className="text-sm text-gray-500">
                {filteredBreeds.length} resultado(s) encontrado(s)
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>
                  <Button
                    variant="ghost"
                    onClick={() => handleSort('name')}
                    className="h-auto p-0 font-medium hover:bg-transparent"
                  >
                    Nome da Raça
                    <ArrowUpDown className="ml-2 h-4 w-4" />
                  </Button>
                </TableHead>
                <TableHead>
                  <Button
                    variant="ghost"
                    onClick={() => handleSort('size')}
                    className="h-auto p-0 font-medium hover:bg-transparent"
                  >
                    Porte
                    <ArrowUpDown className="ml-2 h-4 w-4" />
                  </Button>
                </TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody ref={tableBodyRef}>
              {(searchTerm ? filteredBreeds : breedsWithSizes).map((breed) => (
                <TableRow 
                  key={breed.name} 
                  className={`h-8 transition-colors ${
                    highlightedBreed === breed.name ? 'bg-yellow-100 border-yellow-300' : ''
                  }`}
                  data-breed-name={breed.name}
                >
                  <TableCell className="font-medium py-1">{breed.name}</TableCell>
                  <TableCell className="py-1">
                    <Select
                      value={breed.size}
                      onValueChange={(value) => handleSizeChange(breed.name, value)}
                    >
                      <SelectTrigger className="w-32 h-8">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {sizeOptions.map((option) => (
                          <SelectItem key={option} value={option}>
                            {option}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell className="text-right py-1">
                    <div className="flex justify-end space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openEditDialog(breed.name)}
                        className="h-8 px-2"
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openDeleteDialog(breed.name)}
                        className="text-red-600 hover:text-red-700 h-8 px-2"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Add Breed Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Adicionar Nova Raça</DialogTitle>
            <DialogDescription>
              Digite o nome da nova raça de cachorro e selecione o porte.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="newBreed">Nome da Raça</Label>
              <Input
                id="newBreed"
                value={newBreedName}
                onChange={(e) => setNewBreedName(e.target.value)}
                placeholder="Ex: Husky Siberiano"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="newBreedSize">Porte</Label>
              <Select value={newBreedSize} onValueChange={setNewBreedSize}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {sizeOptions.map((option) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleAddBreed}>
              Adicionar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Breed Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Raça</DialogTitle>
            <DialogDescription>
              Modifique o nome da raça de cachorro e o porte.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="editBreed">Nome da Raça</Label>
              <Input
                id="editBreed"
                value={editBreedName}
                onChange={(e) => setEditBreedName(e.target.value)}
                placeholder="Ex: Husky Siberiano"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="editBreedSize">Porte</Label>
              <Select value={editBreedSize} onValueChange={setEditBreedSize}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {sizeOptions.map((option) => (
                    <SelectItem key={option} value={option}>
                      {option}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleEditBreed}>
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Breed Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Excluir Raça</DialogTitle>
            <DialogDescription>
              Tem certeza que deseja excluir a raça "{deletingBreed}"? Esta ação não pode ser desfeita.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancelar
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleDeleteBreed}
            >
              Excluir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Size Options Manager Dialog */}
      <Dialog open={isSizeManagerOpen} onOpenChange={setIsSizeManagerOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Gerenciar Portes</DialogTitle>
            <DialogDescription>
              Adicione, edite ou remova opções de porte dos cachorros.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Adicionar Novo Porte</Label>
              <div className="flex space-x-2">
                <Input
                  value={newSizeOption}
                  onChange={(e) => setNewSizeOption(e.target.value)}
                  placeholder="Ex: Extra Grande"
                />
                <Button onClick={handleAddSizeOption} size="sm">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Portes Existentes</Label>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {sizeOptions.map((option) => (
                  <div key={option} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <span className="font-medium">{option}</span>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuItem onClick={() => openEditSizeDialog(option)}>
                          <Edit className="h-4 w-4 mr-2" />
                          Editar
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => handleDeleteSizeOption(option)}
                          className="text-red-600"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Excluir
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setIsSizeManagerOpen(false)}>
              Fechar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Size Option Dialog */}
      <Dialog open={isEditSizeDialogOpen} onOpenChange={setIsEditSizeDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Porte</DialogTitle>
            <DialogDescription>
              Modifique o nome do porte.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="editSizeOption">Nome do Porte</Label>
              <Input
                id="editSizeOption"
                value={editSizeOptionName}
                onChange={(e) => setEditSizeOptionName(e.target.value)}
                placeholder="Ex: Extra Grande"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditSizeDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleEditSizeOption}>
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default DogBreedManager;

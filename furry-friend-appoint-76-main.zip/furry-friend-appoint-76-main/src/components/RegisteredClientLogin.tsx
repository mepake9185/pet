
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PawPrint, ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useClients } from "@/contexts/ClientContext";
import { useCompanyData } from "@/contexts/CompanyDataContext";

interface RegisteredClientLoginProps {
  onBack: () => void;
  onLoginSuccess: () => void;
}

const RegisteredClientLogin = ({ onBack, onLoginSuccess }: RegisteredClientLoginProps) => {
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const { getClientByEmail, setCurrentClient, currentCompanySlug } = useClients();
  const { companyData } = useCompanyData();

  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleLogin = async () => {
    if (!email.trim()) {
      toast({
        title: "Email obrigatório",
        description: "Por favor, digite seu email.",
        variant: "destructive",
      });
      return;
    }

    if (!validateEmail(email)) {
      toast({
        title: "Email inválido",
        description: "Por favor, digite um email válido.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const client = getClientByEmail(email, currentCompanySlug || undefined);
      
      if (client) {
        setCurrentClient(client);
        toast({
          title: "Login realizado com sucesso!",
          description: `Bem-vindo(a), ${client.name}!`,
        });
        onLoginSuccess();
      } else {
        toast({
          title: "Cliente não encontrado",
          description: `Email não cadastrado em ${companyData.name}. Verifique o email digitado ou solicite seu cadastro.`,
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Erro no login",
        description: "Tente novamente mais tarde.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleLogin();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <Card className="border-0 shadow-xl bg-white/90 backdrop-blur-sm">
          <CardContent className="p-8">
            <div className="text-center mb-6">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-3 rounded-2xl w-fit mx-auto mb-4">
                <PawPrint className="h-6 w-6 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900">{companyData.name}</h2>
              <p className="text-gray-600 mt-2">Entre com seu email para acessar seus agendamentos</p>
            </div>
            
            <div className="space-y-4">
              <div>
                <Input
                  type="email"
                  placeholder="Digite seu e-mail cadastrado"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className="w-full py-3 rounded-xl"
                />
              </div>
              <Button 
                onClick={handleLogin}
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white py-3 rounded-xl"
              >
                {isLoading ? "Entrando..." : "Entrar"}
              </Button>
              <div className="text-center">
                <Button 
                  variant="ghost" 
                  onClick={onBack}
                  className="text-gray-600 hover:text-gray-800"
                >
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Voltar
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default RegisteredClientLogin;

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, Clock, Users, Edit } from "lucide-react";
import { format, startOfWeek, endOfWeek, eachDayOfInterval, addDays, startOfMonth, endOfMonth, isSameDay } from "date-fns";
import { ptBR } from "date-fns/locale";
import NewAppointmentForm from "@/components/NewAppointmentForm";
import { useCompanyData } from "@/contexts/CompanyDataContext";
import { useClients } from "@/contexts/ClientContext";

type ViewType = "daily" | "weekly" | "monthly";
interface Appointment {
  id: number;
  time: string;
  clientId: number; // Reference to client ID instead of client name
  petName: string; // Pet name from the client's pets
  service: string;
  status: "confirmed" | "pending" | "cancelled";
  date: Date;
  duration?: number; // duration in minutes
  taxiDog?: boolean; // taxi dog service
  createdBy?: string; // user who created the appointment
}

const AppointmentCalendar = () => {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [currentView, setCurrentView] = useState<ViewType>("weekly");
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isNewAppointmentOpen, setIsNewAppointmentOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  const [showNewAppointmentForm, setShowNewAppointmentForm] = useState(false);
  
  // Usando os dados da empresa do Context
  const { companyData } = useCompanyData();
  const { clients, getClientById, currentCompanySlug } = useClients();
  const workingHours = companyData.workingHours;

  // Update current time every minute
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000); // Update every minute

    return () => clearInterval(timer);
  }, []);

  // Dados de exemplo para agendamentos agora referenciam clientes reais
  const [appointments, setAppointments] = useState<Appointment[]>(() => {
    const companyClients = currentCompanySlug ? clients.filter(c => c.companySlug === currentCompanySlug) : clients;
    
    if (companyClients.length === 0) {
      return [];
    }

    return [
      {
        id: 1,
        time: "09:00",
        clientId: companyClients[0]?.id || 1,
        petName: companyClients[0]?.pets[0]?.name || "Rex",
        service: "Banho e Tosa",
        status: "confirmed" as const,
        date: new Date(),
        duration: 60,
        taxiDog: true,
        createdBy: "João Administrador"
      },
      {
        id: 2,
        time: "10:30",
        clientId: companyClients[0]?.id || 1,
        petName: companyClients[0]?.pets[1]?.name || "Luna",
        service: "Banho",
        status: "pending" as const,
        date: new Date(),
        duration: 30,
        taxiDog: false,
        createdBy: "Maria Recepcionista"
      },
      {
        id: 3,
        time: "14:00",
        clientId: companyClients[1]?.id || 2,
        petName: companyClients[1]?.pets[0]?.name || "Max",
        service: "Tosa",
        status: "confirmed" as const,
        date: addDays(new Date(), 1),
        duration: 45,
        taxiDog: true,
        createdBy: "Carlos Gerente"
      },
      {
        id: 4,
        time: "15:30",
        clientId: companyClients[0]?.id || 1,
        petName: companyClients[0]?.pets[0]?.name || "Rex",
        service: "Banho e Tosa",
        status: "confirmed" as const,
        date: addDays(new Date(), 2),
        duration: 90,
        taxiDog: false,
        createdBy: "Ana Funcionária"
      },
      {
        id: 5,
        time: "11:00",
        clientId: companyClients[1]?.id || 2,
        petName: companyClients[1]?.pets[0]?.name || "Max",
        service: "Banho",
        status: "pending" as const,
        date: addDays(new Date(), 3),
        duration: 30,
        taxiDog: true,
        createdBy: "Pedro Auxiliar"
      }
    ].filter(apt => {
      const client = getClientById(apt.clientId);
      return client && client.pets.some(pet => pet.name === apt.petName);
    });
  });

  // Helper function to get client and pet data for an appointment
  const getAppointmentData = (appointment: Appointment) => {
    const client = getClientById(appointment.clientId);
    const pet = client?.pets.find(p => p.name === appointment.petName);
    
    return {
      clientName: client?.name || "Cliente não encontrado",
      petName: appointment.petName,
      petBreed: pet?.breed || "SRD"
    };
  };

  // Helper function to get day name in English for working hours lookup
  const getDayKey = (date: Date): keyof typeof workingHours => {
    const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'] as const;
    return dayNames[date.getDay()];
  };

  // Helper function to check if a time slot is during lunch break
  const isLunchBreakSlot = (time: string, date: Date): boolean => {
    const dayKey = getDayKey(date);
    const daySchedule = workingHours[dayKey];
    
    if (!daySchedule.isOpen || !daySchedule.hasLunchBreak || !daySchedule.lunchStart || !daySchedule.lunchEnd) {
      return false;
    }

    const [hours, minutes] = time.split(':').map(Number);
    const timeInMinutes = hours * 60 + minutes;
    
    const [lunchStartHours, lunchStartMinutes] = daySchedule.lunchStart.split(':').map(Number);
    const lunchStartInMinutes = lunchStartHours * 60 + lunchStartMinutes;
    
    const [lunchEndHours, lunchEndMinutes] = daySchedule.lunchEnd.split(':').map(Number);
    const lunchEndInMinutes = lunchEndHours * 60 + lunchEndMinutes;
    
    return timeInMinutes >= lunchStartInMinutes && timeInMinutes < lunchEndInMinutes;
  };

  // Helper function to check if a time slot is within working hours
  const isWithinWorkingHours = (time: string, date: Date): boolean => {
    const dayKey = getDayKey(date);
    const daySchedule = workingHours[dayKey];
    
    if (!daySchedule.isOpen) {
      return false;
    }

    const [hours, minutes] = time.split(':').map(Number);
    const timeInMinutes = hours * 60 + minutes;
    
    const [startHours, startMinutes] = daySchedule.start.split(':').map(Number);
    const startInMinutes = startHours * 60 + startMinutes;
    
    const [endHours, endMinutes] = daySchedule.end.split(':').map(Number);
    const endInMinutes = endHours * 60 + endMinutes;
    
    return timeInMinutes >= startInMinutes && timeInMinutes < endInMinutes;
  };

  // Helper function to generate available time slots based on working hours
  const generateTimeSlots = (date: Date): string[] => {
    const dayKey = getDayKey(date);
    const daySchedule = workingHours[dayKey];
    
    if (!daySchedule.isOpen) {
      return [];
    }
    
    const timeSlots = [];
    const [startHours, startMinutes] = daySchedule.start.split(':').map(Number);
    const [endHours, endMinutes] = daySchedule.end.split(':').map(Number);
    
    const startInMinutes = startHours * 60 + startMinutes;
    const endInMinutes = endHours * 60 + endMinutes;
    
    for (let minutes = startInMinutes; minutes < endInMinutes; minutes += 30) {
      const hours = Math.floor(minutes / 60);
      const mins = minutes % 60;
      timeSlots.push(`${hours.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}`);
    }
    
    return timeSlots;
  };

  // Helper function to calculate current time position
  const getCurrentTimePosition = (date: Date) => {
    const dayKey = getDayKey(date);
    const daySchedule = workingHours[dayKey];
    
    if (!daySchedule.isOpen) return null;
    
    const now = new Date();
    const currentHours = now.getHours();
    const currentMinutes = now.getMinutes();
    const currentTotalMinutes = currentHours * 60 + currentMinutes;
    
    const [startHours, startMinutes] = daySchedule.start.split(':').map(Number);
    const startInMinutes = startHours * 60 + startMinutes;
    
    const [endHours, endMinutes] = daySchedule.end.split(':').map(Number);
    const endInMinutes = endHours * 60 + endMinutes;
    
    // Check if current time is within working hours
    if (currentTotalMinutes < startInMinutes || currentTotalMinutes > endInMinutes) {
      return null;
    }
    
    const relativeMinutes = currentTotalMinutes - startInMinutes;
    return relativeMinutes;
  };

  // Helper function to format current time
  const formatCurrentTime = () => {
    return currentTime.toLocaleTimeString('pt-BR', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  // Helper function to check if date is today
  const isToday = (date: Date) => {
    const today = new Date();
    return date.toDateString() === today.toDateString();
  };

  const handleAppointmentClick = (appointment: Appointment) => {
    setSelectedAppointment(appointment);
    setIsDialogOpen(true);
  };

  const handleEditAppointment = () => {
    // TODO: Implementar edição do agendamento
    console.log("Editar agendamento:", selectedAppointment);
    setIsDialogOpen(false);
  };

  const handleNewAppointment = (newAppointment: Appointment) => {
    setAppointments(prev => [...prev, newAppointment]);
    console.log("Novo agendamento criado:", newAppointment);
  };

  const getAppointmentsForDate = (date: Date) => {
    return appointments.filter(appointment => isSameDay(appointment.date, date));
  };

  const getAppointmentsForPeriod = () => {
    if (currentView === "daily") {
      return getAppointmentsForDate(selectedDate);
    } else if (currentView === "weekly") {
      const weekStart = startOfWeek(selectedDate, {
        locale: ptBR
      });
      const weekEnd = endOfWeek(selectedDate, {
        locale: ptBR
      });
      return appointments.filter(appointment => appointment.date >= weekStart && appointment.date <= weekEnd);
    } else {
      const monthStart = startOfMonth(selectedDate);
      const monthEnd = endOfMonth(selectedDate);
      return appointments.filter(appointment => appointment.date >= monthStart && appointment.date <= monthEnd);
    }
  };
  
  const navigateDate = (direction: "prev" | "next") => {
    if (currentView === "daily") {
      setSelectedDate(prev => addDays(prev, direction === "next" ? 1 : -1));
    } else if (currentView === "weekly") {
      setSelectedDate(prev => addDays(prev, direction === "next" ? 7 : -7));
    } else {
      setSelectedDate(prev => {
        const newDate = new Date(prev);
        newDate.setMonth(prev.getMonth() + (direction === "next" ? 1 : -1));
        return newDate;
      });
    }
  };

  const renderDailyView = () => {
    const appointmentsForDate = getAppointmentsForDate(selectedDate);
    const timeSlots = generateTimeSlots(selectedDate);

    // Helper function to convert time string to minutes from start of working hours
    const timeToPosition = (time: string) => {
      const dayKey = getDayKey(selectedDate);
      const daySchedule = workingHours[dayKey];
      
      const [hours, minutes] = time.split(':').map(Number);
      const totalMinutes = hours * 60 + minutes;
      
      const [startHours, startMinutes] = daySchedule.start.split(':').map(Number);
      const startInMinutes = startHours * 60 + startMinutes;
      
      const relativeMinutes = totalMinutes - startInMinutes;
      // Each slot is 80px high, representing 30 minutes
      return (relativeMinutes / 30) * 80;
    };

    // Helper function to calculate appointment height based on duration (proportional to slot)
    const getAppointmentHeight = (duration: number = 30) => {
      const calculatedHeight = (duration / 30) * 80; // 80px per 30-minute slot
      return calculatedHeight - 8; // Subtract 8px for spacing and borders
    };

    // Helper function to calculate end time
    const calculateEndTime = (startTime: string, duration: number = 30) => {
      const [hours, minutes] = startTime.split(':').map(Number);
      const startMinutes = hours * 60 + minutes;
      const endMinutes = startMinutes + duration;
      const endHours = Math.floor(endMinutes / 60);
      const endMins = endMinutes % 60;
      return `${endHours.toString().padStart(2, '0')}:${endMins.toString().padStart(2, '0')}`;
    };

    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900 my-[20px]">
            {format(selectedDate, "EEEE, dd 'de' MMMM 'de' yyyy", {
              locale: ptBR
            })}
          </h3>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={() => navigateDate("prev")}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={() => navigateDate("next")}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        <div className="relative border rounded-lg">
          {/* Time slots grid */}
          <div className="space-y-0">
            {timeSlots.length === 0 ? (
              <div className="flex items-center justify-center h-32 text-gray-500">
                Fechado neste dia
              </div>
            ) : (
              timeSlots.map((time) => {
                const isLunchSlot = isLunchBreakSlot(time, selectedDate);
                return (
                  <div key={time} className="flex items-center border-b border-gray-100 h-[80px]">
                    <div className="w-20 text-sm font-medium text-gray-600 flex-shrink-0 p-3 border-r border-gray-100">
                      {time}
                    </div>
                    <div className={`flex-1 text-gray-300 text-sm p-3 ${isLunchSlot ? 'bg-orange-50' : ''}`}>
                      {isLunchSlot ? 'Intervalo de almoço' : 'Horário disponível'}
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Appointments overlay */}
          {timeSlots.length > 0 && (
            <div className="absolute top-0 left-20 right-0 pointer-events-none">
              {appointmentsForDate.map((appointment) => {
                const topPosition = timeToPosition(appointment.time);
                const height = getAppointmentHeight(appointment.duration);
                const endTime = calculateEndTime(appointment.time, appointment.duration);
                const appointmentData = getAppointmentData(appointment);
                
                return (
                  <div
                    key={appointment.id}
                    className="absolute left-0 right-0 mx-1 pointer-events-auto cursor-pointer"
                    style={{
                      top: `${topPosition + 4}px`, // Add 4px top margin for better alignment
                      height: `${height}px`,
                    }}
                    onClick={() => handleAppointmentClick(appointment)}
                  >
                    <div className="flex items-start justify-between p-1.5 bg-gray-50 rounded h-full border border-gray-200 shadow-sm overflow-hidden hover:bg-gray-100 transition-colors">
                      <div className="flex items-start space-x-1 min-w-0 flex-1">
                        <div className="min-w-0 flex-1">
                          <p className="text-xs truncate leading-tight"><span className="font-medium text-gray-900">{appointmentData.clientName}</span> - {appointmentData.petName} {appointmentData.petBreed && `(${appointmentData.petBreed})`}</p>
                          <p className="text-xs text-gray-600 truncate leading-tight">{appointment.service}</p>
                          <p className="text-xs text-gray-500 leading-tight">
                            {appointment.time} - {endTime}
                          </p>
                          <p className="text-xs text-gray-500 leading-tight">
                            Táxi Dog: {appointment.taxiDog ? "sim" : "não"}
                          </p>
                        </div>
                      </div>
                      <Badge 
                        className={`text-xs px-1 py-0 flex-shrink-0 h-fit ${
                          appointment.status === "confirmed" 
                            ? "bg-green-100 text-green-800" 
                            : appointment.status === "pending" 
                            ? "bg-yellow-100 text-yellow-800" 
                            : "bg-red-100 text-red-800"
                        }`}
                      >
                        {appointment.status === "confirmed" ? "OK" : appointment.status === "pending" ? "Pend" : "Canc"}
                      </Badge>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Appointment Details Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Detalhes do Agendamento</DialogTitle>
            </DialogHeader>
            {selectedAppointment && (
              <div className="space-y-4">
                <div className="space-y-2">
                  {(() => {
                    const appointmentData = getAppointmentData(selectedAppointment);
                    return (
                      <>
                        <p className="font-medium text-gray-900">
                          {appointmentData.clientName} - {appointmentData.petName}
                        </p>
                        <p className="text-sm text-gray-600">
                          {selectedAppointment.service}
                        </p>
                        <p className="text-sm text-gray-500">
                          {selectedAppointment.time} - {calculateEndTime(selectedAppointment.time, selectedAppointment.duration)}
                        </p>
                        <p className="text-sm text-gray-500">
                          Táxi Dog: {selectedAppointment.taxiDog ? "sim" : "não"}
                        </p>
                        <p className="text-sm text-gray-500">
                          Criado por: {selectedAppointment.createdBy}
                        </p>
                      </>
                    );
                  })()}
                </div>
                
                <div className="flex items-center justify-between pt-4 border-t">
                  <Badge 
                    className={`${
                      selectedAppointment.status === "confirmed" 
                        ? "bg-green-100 text-green-800" 
                        : selectedAppointment.status === "pending" 
                        ? "bg-yellow-100 text-yellow-800" 
                        : selectedAppointment.status === "cancelled" 
                        ? "bg-red-100 text-red-800"
                        : ""
                    }`}
                  >
                    {selectedAppointment.status === "confirmed" ? "Confirmado" : 
                     selectedAppointment.status === "pending" ? "Pendente" : "Cancelado"}
                  </Badge>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleEditAppointment}
                    className="flex items-center space-x-1"
                  >
                    <Edit className="h-3 w-3" />
                    <span>Editar</span>
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    );
  };

  const renderWeeklyView = () => {
    const weekStart = startOfWeek(selectedDate, {
      locale: ptBR
    });
    const weekEnd = endOfWeek(selectedDate, {
      locale: ptBR
    });
    const weekDays = eachDayOfInterval({
      start: weekStart,
      end: weekEnd
    });

    // Helper function to calculate appointment height based on duration
    const getAppointmentHeight = (duration: number = 30) => {
      const calculatedHeight = (duration / 30) * 60; // 60px per 30-minute slot
      return calculatedHeight - 4; // Subtract 4px for spacing and borders
    };

    // Helper function to calculate end time
    const calculateEndTime = (startTime: string, duration: number = 30) => {
      const [hours, minutes] = startTime.split(':').map(Number);
      const startMinutes = hours * 60 + minutes;
      const endMinutes = startMinutes + duration;
      const endHours = Math.floor(endMinutes / 60);
      const endMins = endMinutes % 60;
      return `${endHours.toString().padStart(2, '0')}:${endMins.toString().padStart(2, '0')}`;
    };

    // Generate unified time slots for the week view based on earliest start and latest end
    const allTimeSlots = [];
    let earliestStart = 24 * 60; // Start with end of day in minutes
    let latestEnd = 0;

    // Find the earliest start and latest end across all open days
    weekDays.forEach(day => {
      const dayKey = getDayKey(day);
      const daySchedule = workingHours[dayKey];
      
      if (daySchedule.isOpen) {
        const [startHours, startMinutes] = daySchedule.start.split(':').map(Number);
        const startInMinutes = startHours * 60 + startMinutes;
        
        const [endHours, endMinutes] = daySchedule.end.split(':').map(Number);
        const endInMinutes = endHours * 60 + endMinutes;
        
        earliestStart = Math.min(earliestStart, startInMinutes);
        latestEnd = Math.max(latestEnd, endInMinutes);
      }
    });

    // Generate time slots from earliest start to latest end
    if (earliestStart < latestEnd) {
      for (let minutes = earliestStart; minutes < latestEnd; minutes += 30) {
        const hours = Math.floor(minutes / 60);
        const mins = minutes % 60;
        allTimeSlots.push(`${hours.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}`);
      }
    }

    // Helper function to convert time string to position
    const timeToPosition = (time: string) => {
      // Find the exact slot index for this time
      const slotIndex = allTimeSlots.findIndex(slot => slot === time);
      
      if (slotIndex !== -1) {
        // Use the exact slot position (60px per slot)
        return slotIndex * 60;
      }
      
      // Fallback calculation if slot not found
      const [hours, minutes] = time.split(':').map(Number);
      const totalMinutes = hours * 60 + minutes;
      const relativeMinutes = totalMinutes - earliestStart;
      return (relativeMinutes / 30) * 60;
    };

    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900 my-[20px]">
            {format(weekStart, "dd/MM", {
              locale: ptBR
            })} - {format(weekEnd, "dd/MM/yyyy", {
              locale: ptBR
            })}
          </h3>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={() => navigateDate("prev")}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={() => navigateDate("next")}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        <div className="relative border rounded-lg overflow-hidden">
          {/* Header with days */}
          <div className="flex border-b border-gray-200 h-[73px]">
            <div className="w-16 text-sm font-medium text-gray-600 p-3 border-r border-gray-200 bg-gray-50">
              Hora
            </div>
            {weekDays.map(day => {
              const isDayToday = isSameDay(day, new Date());
              const dayKey = getDayKey(day);
              const daySchedule = workingHours[dayKey];
              return (
                <div key={day.toISOString()} className={`flex-1 text-center p-3 border-r border-gray-200 ${isDayToday ? 'bg-primary/10' : daySchedule.isOpen ? 'bg-gray-50' : 'bg-red-50'}`}>
                  <p className={`text-xs font-medium ${isDayToday ? 'text-primary' : daySchedule.isOpen ? 'text-gray-700' : 'text-red-600'}`}>
                    {format(day, "EEE", { locale: ptBR })}
                  </p>
                  <p className={`text-sm ${isDayToday ? 'text-primary' : daySchedule.isOpen ? 'text-gray-900' : 'text-red-600'}`}>
                    {format(day, "dd", { locale: ptBR })}
                  </p>
                  {!daySchedule.isOpen && (
                    <p className="text-xs text-red-600">Fechado</p>
                  )}
                </div>
              );
            })}
          </div>

          {/* Time slots grid */}
          <div className="space-y-0">
            {allTimeSlots.map((time, index) => (
              <div key={time} className="flex border-b border-gray-100 h-[60px]">
                <div className="w-16 text-xs font-medium text-gray-600 flex-shrink-0 p-2 border-r border-gray-100 bg-gray-50">
                  {time}
                </div>
                {weekDays.map(day => {
                  const dayKey = getDayKey(day);
                  const daySchedule = workingHours[dayKey];
                  const isWithinHours = isWithinWorkingHours(time, day);
                  const isLunchSlot = isLunchBreakSlot(time, day);
                  
                  return (
                    <div key={`${day.toISOString()}-${time}`} className={`flex-1 border-r border-gray-100 text-xs p-1 ${
                      !daySchedule.isOpen ? 'bg-red-50' : 
                      !isWithinHours ? 'bg-gray-100' :
                      isLunchSlot ? 'bg-orange-50' : ''
                    }`}>
                      {/* Empty slot for appointments overlay */}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>

          {/* Appointments overlay */}
          <div className="absolute top-[73px] left-16 right-0 pointer-events-none">
            {weekDays.map((day, dayIndex) => {
              const dayAppointments = getAppointmentsForDate(day);
              const dayWidth = `${100 / 7}%`;
              const leftPosition = `${(100 / 7) * dayIndex}%`;
              
              return (
                <div
                  key={day.toISOString()}
                  className="absolute top-0 bottom-0"
                  style={{
                    left: leftPosition,
                    width: dayWidth,
                  }}
                >
                  {dayAppointments.map((appointment) => {
                    const topPosition = timeToPosition(appointment.time);
                    const height = getAppointmentHeight(appointment.duration);
                    const endTime = calculateEndTime(appointment.time, appointment.duration);
                    const appointmentData = getAppointmentData(appointment);
                    
                    return (
                      <div
                        key={appointment.id}
                        className="absolute left-0 right-0 mx-0.5 pointer-events-auto cursor-pointer"
                        style={{
                          top: `${topPosition}px`,
                          height: `${height}px`,
                        }}
                        onClick={() => handleAppointmentClick(appointment)}
                      >
                        <div className="flex flex-col justify-between p-1 bg-gray-50 rounded h-full border border-gray-200 shadow-sm overflow-hidden hover:bg-gray-100 transition-colors">
                          <div className="min-w-0 flex-1">
                            <p className="font-bold text-gray-900 text-xs truncate leading-tight">{appointmentData.clientName}</p>
                            <p className="text-xs text-gray-600 truncate leading-tight">{appointmentData.petName} ({appointmentData.petBreed})</p>
                            <p className="text-xs text-gray-500 leading-tight">{appointment.time} : {endTime}</p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>

        {/* Appointment Details Dialog - same as daily view */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Detalhes do Agendamento</DialogTitle>
            </DialogHeader>
            {selectedAppointment && (
              <div className="space-y-4">
                <div className="space-y-2">
                  {(() => {
                    const appointmentData = getAppointmentData(selectedAppointment);
                    return (
                      <>
                        <p className="font-medium text-gray-900">
                          {appointmentData.clientName} - {appointmentData.petName}
                        </p>
                        <p className="text-sm text-gray-600">
                          {selectedAppointment.service}
                        </p>
                        <p className="text-sm text-gray-500">
                          {selectedAppointment.time} - {calculateEndTime(selectedAppointment.time, selectedAppointment.duration)}
                        </p>
                        <p className="text-sm text-gray-500">
                          Táxi Dog: {selectedAppointment.taxiDog ? "sim" : "não"}
                        </p>
                        <p className="text-sm text-gray-500">
                          Criado por: {selectedAppointment.createdBy}
                        </p>
                      </>
                    );
                  })()}
                </div>
                
                <div className="flex items-center justify-between pt-4 border-t">
                  <Badge 
                    className={`${
                      selectedAppointment.status === "confirmed" 
                        ? "bg-green-100 text-green-800" 
                        : selectedAppointment.status === "pending" 
                        ? "bg-yellow-100 text-yellow-800" 
                        : selectedAppointment.status === "cancelled" 
                        ? "bg-red-100 text-red-800"
                        : ""
                    }`}
                  >
                    {selectedAppointment.status === "confirmed" ? "Confirmado" : 
                     selectedAppointment.status === "pending" ? "Pendente" : "Cancelado"}
                  </Badge>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleEditAppointment}
                    className="flex items-center space-x-1"
                  >
                    <Edit className="h-3 w-3" />
                    <span>Editar</span>
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    );
  };
  
  const renderMonthlyView = () => {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900 my-[20px]">
            {format(selectedDate, "MMMM 'de' yyyy", {
              locale: ptBR
            })}
          </h3>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={() => navigateDate("prev")}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={() => navigateDate("next")}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        <Calendar
          mode="single"
          selected={selectedDate}
          onSelect={date => date && setSelectedDate(date)}
          locale={ptBR}
          className="rounded-md border w-full"
          modifiers={{
            hasAppointments: date => getAppointmentsForDate(date).length > 0
          }}
          modifiersStyles={{
            hasAppointments: {
              backgroundColor: 'hsl(var(--primary))',
              color: 'white',
              borderRadius: '50%'
            }
          }}
        />
        
        <div className="space-y-3">
          <h4 className="font-medium text-gray-900">
            Agendamentos para {format(selectedDate, "dd 'de' MMMM", {
              locale: ptBR
            })}
          </h4>
          {getAppointmentsForDate(selectedDate).length === 0 ? (
            <p className="text-gray-500 text-sm">Nenhum agendamento para este dia</p>
          ) : (
            getAppointmentsForDate(selectedDate).map(appointment => {
              const appointmentData = getAppointmentData(appointment);
              return (
                <div key={appointment.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <Clock className="h-4 w-4 text-primary" />
                    <div>
                      <p className="font-medium text-sm">{appointment.time} - {appointmentData.clientName}</p>
                      <p className="text-xs text-gray-600">{appointmentData.petName} - {appointment.service}</p>
                    </div>
                  </div>
                  <Badge variant={appointment.status === "confirmed" ? "default" : "secondary"}>
                    {appointment.status === "confirmed" ? "Confirmado" : "Pendente"}
                  </Badge>
                </div>
              );
            })
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Agendamentos</h1>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button variant={currentView === "daily" ? "default" : "outline"} size="sm" onClick={() => setCurrentView("daily")}>
            Diário
          </Button>
          <Button variant={currentView === "weekly" ? "default" : "outline"} size="sm" onClick={() => setCurrentView("weekly")}>
            Semanal
          </Button>
          <Button variant={currentView === "monthly" ? "default" : "outline"} size="sm" onClick={() => setCurrentView("monthly")}>
            Mensal
          </Button>
        </div>
      </div>

      {/* Novo Agendamento Button */}
      <div className="flex justify-end">
        <Button onClick={() => setShowNewAppointmentForm(true)} className="bg-primary text-primary-foreground hover:bg-primary/90">
          <CalendarIcon className="h-4 w-4 mr-2" />
          Novo Agendamento
        </Button>
      </div>

      <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
        <CardContent>
          {currentView === "daily" && renderDailyView()}
          {currentView === "weekly" && renderWeeklyView()}
          {currentView === "monthly" && renderMonthlyView()}
        </CardContent>
      </Card>

      {/* New Appointment Form */}
      <NewAppointmentForm
        isOpen={showNewAppointmentForm}
        onClose={() => setShowNewAppointmentForm(false)}
        onSubmit={handleNewAppointment}
        selectedDate={selectedDate}
        workingHours={companyData.workingHours}
        existingAppointments={appointments}
      />
    </div>
  );
};

export default AppointmentCalendar;

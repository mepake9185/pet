
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, MapPin, Phone, PawPrint, Plus, User, LogOut } from "lucide-react";
import { useClients } from "@/contexts/ClientContext";
import NewAppointmentForm from "./NewAppointmentForm";

interface ClientDashboardProps {
  onLogout: () => void;
}

const ClientDashboard = ({ onLogout }: ClientDashboardProps) => {
  const [activeTab, setActiveTab] = useState("appointments");
  const [showNewAppointment, setShowNewAppointment] = useState(false);
  const { currentClient, setCurrentClient } = useClients();

  const handleLogout = () => {
    setCurrentClient(null);
    onLogout();
  };

  const handleNewAppointmentSubmit = (appointmentData: any) => {
    console.log("New appointment created:", appointmentData);
    // Here you would typically save the appointment to your context/database
    setShowNewAppointment(false);
  };

  const upcomingAppointments = [
    {
      id: 1,
      petName: "Rex",
      service: "Banho e Tosa",
      date: "2024-06-15",
      time: "14:00",
      professional: "Ana Silva",
      status: "confirmed"
    }
  ];

  if (!currentClient) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-2 rounded-xl mr-3">
                <PawPrint className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-xl font-bold text-gray-900">PetSchedule</h1>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center text-gray-700">
                <User className="h-5 w-5 mr-2" />
                <span className="font-medium">{currentClient.name}</span>
              </div>
              <Button 
                variant="ghost" 
                onClick={handleLogout}
                className="text-gray-600 hover:text-gray-800"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Sair
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Navigation Tabs */}
        <div className="flex space-x-1 bg-gray-100 p-1 rounded-xl mb-8 w-fit">
          <button
            onClick={() => setActiveTab("appointments")}
            className={`px-6 py-2 rounded-lg font-medium transition-all duration-200 ${
              activeTab === "appointments"
                ? "bg-white text-blue-600 shadow-sm"
                : "text-gray-600 hover:text-gray-800"
            }`}
          >
            Agendamentos
          </button>
          <button
            onClick={() => setActiveTab("pets")}
            className={`px-6 py-2 rounded-lg font-medium transition-all duration-200 ${
              activeTab === "pets"
                ? "bg-white text-blue-600 shadow-sm"
                : "text-gray-600 hover:text-gray-800"
            }`}
          >
            Meus Pets
          </button>
          <button
            onClick={() => setActiveTab("profile")}
            className={`px-6 py-2 rounded-lg font-medium transition-all duration-200 ${
              activeTab === "profile"
                ? "bg-white text-blue-600 shadow-sm"
                : "text-gray-600 hover:text-gray-800"
            }`}
          >
            Meu Perfil
          </button>
        </div>

        {activeTab === "appointments" && (
          <div>
            {/* Quick Actions */}
            <div className="mb-8">
              <Button 
                onClick={() => setShowNewAppointment(true)}
                className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white px-6 py-3 rounded-xl"
              >
                <Plus className="h-5 w-5 mr-2" />
                Novo Agendamento
              </Button>
            </div>

            {/* Upcoming Appointments */}
            <div className="grid gap-6">
              <h2 className="text-2xl font-bold text-gray-900">Próximos Agendamentos</h2>
              {upcomingAppointments.length > 0 ? (
                upcomingAppointments.map((appointment) => (
                  <Card key={appointment.id} className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center">
                          <div className="bg-gradient-to-r from-blue-500 to-blue-600 p-3 rounded-xl mr-4">
                            <PawPrint className="h-6 w-6 text-white" />
                          </div>
                          <div>
                            <h3 className="text-lg font-bold text-gray-900">{appointment.petName}</h3>
                            <p className="text-gray-600">{appointment.service}</p>
                          </div>
                        </div>
                        <Badge 
                          className={
                            appointment.status === "confirmed" 
                              ? "bg-green-100 text-green-800" 
                              : "bg-yellow-100 text-yellow-800"
                          }
                        >
                          {appointment.status === "confirmed" ? "Confirmado" : "Pendente"}
                        </Badge>
                      </div>
                      
                      <div className="grid md:grid-cols-3 gap-4 text-sm text-gray-600">
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-2" />
                          {new Date(appointment.date).toLocaleDateString('pt-BR')}
                        </div>
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-2" />
                          {appointment.time}
                        </div>
                        <div className="flex items-center">
                          <User className="h-4 w-4 mr-2" />
                          {appointment.professional}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                  <CardContent className="p-6 text-center">
                    <Calendar className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                    <p className="text-gray-600">Você não possui agendamentos no momento.</p>
                    <Button 
                      onClick={() => setShowNewAppointment(true)}
                      className="mt-4 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
                    >
                      Fazer primeiro agendamento
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        )}

        {activeTab === "pets" && (
          <div>
            <div className="grid gap-6">
              <h2 className="text-2xl font-bold text-gray-900">Meus Pets</h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {currentClient.pets.map((pet, index) => (
                  <Card key={index} className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                    <CardContent className="p-6 text-center">
                      <div className="bg-gradient-to-r from-indigo-500 to-indigo-600 p-4 rounded-full w-fit mx-auto mb-4">
                        <PawPrint className="h-8 w-8 text-white" />
                      </div>
                      <h3 className="text-xl font-bold text-gray-900 mb-2">{pet.name}</h3>
                      <div className="space-y-2 text-sm text-gray-600">
                        <p><span className="font-medium">Raça:</span> {pet.breed}</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === "profile" && (
          <div>
            <div className="grid gap-6">
              <h2 className="text-2xl font-bold text-gray-900">Meu Perfil</h2>
              <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium text-gray-500">Nome</label>
                      <p className="text-lg text-gray-900">{currentClient.name}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-500">Email</label>
                      <p className="text-lg text-gray-900">{currentClient.email}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-500">Telefone</label>
                      <p className="text-lg text-gray-900">{currentClient.phone}</p>
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-500">Endereço</label>
                      <p className="text-lg text-gray-900">
                        {currentClient.address}, {currentClient.addressNumber} 
                        {currentClient.complement && ` - ${currentClient.complement}`}
                        <br />
                        {currentClient.neighborhood}, {currentClient.city} - {currentClient.state}
                        <br />
                        CEP: {currentClient.cep}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>

      {showNewAppointment && (
        <NewAppointmentForm
          isOpen={showNewAppointment}
          onClose={() => setShowNewAppointment(false)}
          onSubmit={handleNewAppointmentSubmit}
        />
      )}
    </div>
  );
};

export default ClientDashboard;

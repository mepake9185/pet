
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Switch } from "@/components/ui/switch";
import { Calendar } from "@/components/ui/calendar";
import { Checkbox } from "@/components/ui/checkbox";
import { CalendarIcon, AlertTriangle, Check, ChevronsUpDown } from "lucide-react";
import { format, isSameDay } from "date-fns";
import { ptBR } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { useCompanyData } from "@/contexts/CompanyDataContext";
import { useClients } from "@/contexts/ClientContext";
import { useDogBreeds } from "@/contexts/DogBreedContext";
import { usePetShopServices } from "@/contexts/PetShopServiceContext";

interface NewAppointmentFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (appointment: any) => void;
  selectedDate?: Date;
  workingHours?: any;
  existingAppointments?: any[];
}

interface PetShopService {
  id: number;
  name: string;
  targetType: 'breed' | 'size';
  targetValue: string;
  price: number;
  durationMinutes: number;
}

const NewAppointmentForm = ({ isOpen, onClose, onSubmit, selectedDate, existingAppointments = [] }: NewAppointmentFormProps) => {
  const { toast } = useToast();
  const { companyData } = useCompanyData();
  const { clients, currentCompanySlug, setCurrentCompanySlug } = useClients();
  const { breeds } = useDogBreeds();
  const { services } = usePetShopServices();
  const workingHours = companyData.workingHours;
  
  // Debug logs to identify the issue
  useEffect(() => {
    console.log("=== NewAppointmentForm Debug ===");
    console.log("currentCompanySlug from useClients:", currentCompanySlug);
    console.log("companyData.slug from useCompanyData:", companyData.slug);
    console.log("All clients:", clients);
    console.log("Total clients count:", clients.length);
    
    // Log each client with their company slug
    clients.forEach((client, index) => {
      console.log(`Client ${index + 1}: ${client.name} (companySlug: ${client.companySlug})`);
    });
  }, [currentCompanySlug, companyData.slug, clients]);

  // Sync company slug between contexts if needed
  useEffect(() => {
    if (companyData.slug && (!currentCompanySlug || currentCompanySlug !== companyData.slug)) {
      console.log("Syncing company slug:", companyData.slug);
      setCurrentCompanySlug(companyData.slug);
    }
  }, [companyData.slug, currentCompanySlug, setCurrentCompanySlug]);

  // Use effective company slug with better fallback logic
  const effectiveCompanySlug = currentCompanySlug || companyData.slug || "pet-shop-exemplo";
  
  // Filter clients by effective company slug with more permissive matching
  const companyClients = clients.filter(client => {
    if (!client.companySlug) {
      console.log(`Client ${client.name} has no companySlug, including anyway`);
      return true; // Include clients without companySlug as fallback
    }
    
    const matches = client.companySlug === effectiveCompanySlug;
    if (!matches) {
      console.log(`Client ${client.name} (${client.companySlug}) doesn't match effective slug: ${effectiveCompanySlug}`);
    }
    return matches;
  });

  console.log("Effective company slug:", effectiveCompanySlug);
  console.log("Filtered company clients:", companyClients);
  console.log("Company clients count:", companyClients.length);
  
  // Show all clients if no company-specific clients found
  const displayClients = companyClients.length > 0 ? companyClients : clients;
  
  console.log("Final display clients:", displayClients);
  console.log("Final display clients count:", displayClients.length);
  
  const [formData, setFormData] = useState({
    client: "",
    clientId: null as number | null,
    pet: "",
    services: [] as number[], // Changed to array for multiple services
    date: selectedDate || new Date(),
    timeSlots: [] as string[], // Changed to array for multiple time slots
    taxiDog: false,
    status: "pending" as const
  });

  const [clientSearchOpen, setClientSearchOpen] = useState(false);
  const [selectedClient, setSelectedClient] = useState<any>(null);
  const [availablePets, setAvailablePets] = useState<string[]>([]);
  const [selectedPet, setSelectedPet] = useState<any>(null);

  // Get pet size based on breed - simplified since breeds is an array of strings
  const getPetSize = (breedName: string): string => {
    // Since breeds is an array of strings, we'll use a simple mapping
    // In a real app, this would come from a more structured breeds data
    const smallBreeds = ['Yorkshire', 'Chihuahua', 'Poodle Toy', 'Maltês'];
    const largeBreeds = ['Golden Retriever', 'Labrador', 'Pastor Alemão', 'Rottweiler'];
    const giantBreeds = ['São Bernardo', 'Dogue Alemão', 'Mastiff'];
    
    if (smallBreeds.includes(breedName)) return "Pequeno";
    if (largeBreeds.includes(breedName)) return "Grande";
    if (giantBreeds.includes(breedName)) return "Gigante";
    
    return "Médio"; // Default fallback
  };

  // Filter and prioritize services based on selected pet
  const getAvailableServices = () => {
    if (!selectedPet) return [];
    
    const petBreed = selectedPet.breed;
    const petSize = getPetSize(petBreed);
    
    console.log(`Pet: ${selectedPet.name}, Breed: ${petBreed}, Size: ${petSize}`);
    
    // Get services that match by breed or size
    const breedServices = services.filter(service => 
      service.targetType === 'breed' && service.targetValue === petBreed
    );
    
    const sizeServices = services.filter(service => 
      service.targetType === 'size' && service.targetValue === petSize
    );
    
    // Group services by name to handle duplicates
    const serviceGroups: { [key: string]: any[] } = {};
    
    [...breedServices, ...sizeServices].forEach(service => {
      if (!serviceGroups[service.name]) {
        serviceGroups[service.name] = [];
      }
      serviceGroups[service.name].push(service);
    });
    
    // For each service name, prioritize breed-specific over size-specific
    const finalServices: any[] = [];
    
    Object.keys(serviceGroups).forEach(serviceName => {
      const servicesForName = serviceGroups[serviceName];
      
      // Check if there's a breed-specific service
      const breedSpecific = servicesForName.find(s => s.targetType === 'breed');
      
      if (breedSpecific) {
        finalServices.push(breedSpecific);
      } else {
        // If no breed-specific, use size-specific
        const sizeSpecific = servicesForName.find(s => s.targetType === 'size');
        if (sizeSpecific) {
          finalServices.push(sizeSpecific);
        }
      }
    });
    
    console.log("Available services for pet:", finalServices);
    return finalServices;
  };

  const availableServices = getAvailableServices();

  // Helper function to get day name in English for working hours lookup
  const getDayKey = (date: Date): keyof typeof workingHours => {
    const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'] as const;
    return dayNames[date.getDay()];
  };

  // Helper function to check if a time slot is during lunch break
  const isLunchBreakSlot = (time: string, date: Date): boolean => {
    const dayKey = getDayKey(date);
    const daySchedule = workingHours[dayKey];
    
    if (!daySchedule.isOpen || !daySchedule.hasLunchBreak || !daySchedule.lunchStart || !daySchedule.lunchEnd) {
      return false;
    }

    const [hours, minutes] = time.split(':').map(Number);
    const timeInMinutes = hours * 60 + minutes;
    
    const [lunchStartHours, lunchStartMinutes] = daySchedule.lunchStart.split(':').map(Number);
    const lunchStartInMinutes = lunchStartHours * 60 + lunchStartMinutes;
    
    const [lunchEndHours, lunchEndMinutes] = daySchedule.lunchEnd.split(':').map(Number);
    const lunchEndInMinutes = lunchEndHours * 60 + lunchEndMinutes;
    
    return timeInMinutes >= lunchStartInMinutes && timeInMinutes < lunchEndInMinutes;
  };

  // Helper function to check if a time slot is within working hours
  const isWithinWorkingHours = (time: string, date: Date): boolean => {
    const dayKey = getDayKey(date);
    const daySchedule = workingHours[dayKey];
    
    if (!daySchedule.isOpen) {
      return false;
    }

    const [hours, minutes] = time.split(':').map(Number);
    const timeInMinutes = hours * 60 + minutes;
    
    const [startHours, startMinutes] = daySchedule.start.split(':').map(Number);
    const startInMinutes = startHours * 60 + startMinutes;
    
    const [endHours, endMinutes] = daySchedule.end.split(':').map(Number);
    const endInMinutes = endHours * 60 + endMinutes;
    
    return timeInMinutes >= startInMinutes && timeInMinutes < endInMinutes;
  };

  // Calculate total duration from selected services
  const getTotalDuration = () => {
    return formData.services.reduce((total, serviceId) => {
      const service = availableServices.find(s => s.id === serviceId);
      return total + (service?.durationMinutes || 0);
    }, 0);
  };

  // CORREÇÃO: Função melhorada para verificar conflitos de horários
  const isTimeSlotConflicted = (timeSlot: string, date: Date): boolean => {
    const totalDuration = getTotalDuration();
    // Se não há serviços selecionados, usa duração padrão de 30 minutos
    const serviceDuration = totalDuration > 0 ? totalDuration : 30;
    
    const [slotHours, slotMinutes] = timeSlot.split(':').map(Number);
    const slotStartInMinutes = slotHours * 60 + slotMinutes;
    const slotEndInMinutes = slotStartInMinutes + serviceDuration;
    
    console.log(`Checking conflicts for ${timeSlot} on ${format(date, 'yyyy-MM-dd')} (duration: ${serviceDuration}min)`);
    
    return existingAppointments.some(appointment => {
      // Usar isSameDay para comparação precisa de datas
      const appointmentDate = new Date(appointment.date);
      
      if (!isSameDay(appointmentDate, date)) {
        return false;
      }
      
      const [appointmentHours, appointmentMinutes] = appointment.time.split(':').map(Number);
      const appointmentStartInMinutes = appointmentHours * 60 + appointmentMinutes;
      const appointmentEndInMinutes = appointmentStartInMinutes + (appointment.duration || 30);
      
      // Verificar se há qualquer sobreposição entre os dois períodos
      const hasOverlap = (slotStartInMinutes < appointmentEndInMinutes && slotEndInMinutes > appointmentStartInMinutes);
      
      if (hasOverlap) {
        console.log(`Conflict detected: ${timeSlot} (${slotStartInMinutes}-${slotEndInMinutes}) overlaps with existing appointment ${appointment.time} (${appointmentStartInMinutes}-${appointmentEndInMinutes})`);
      }
      
      return hasOverlap;
    });
  };

  // Check if the entire duration fits within working hours and doesn't cross lunch break
  const isTimeSlotValid = (timeSlot: string, date: Date): boolean => {
    const totalDuration = getTotalDuration();
    const serviceDuration = totalDuration > 0 ? totalDuration : 30;
    
    const [slotHours, slotMinutes] = timeSlot.split(':').map(Number);
    const slotStartInMinutes = slotHours * 60 + slotMinutes;
    const slotEndInMinutes = slotStartInMinutes + serviceDuration;
    
    const dayKey = getDayKey(date);
    const daySchedule = workingHours[dayKey];
    
    if (!daySchedule.isOpen) {
      return false;
    }
    
    const [endHours, endMinutes] = daySchedule.end.split(':').map(Number);
    const workingEndInMinutes = endHours * 60 + endMinutes;
    
    // Check if appointment would end after working hours
    if (slotEndInMinutes > workingEndInMinutes) {
      return false;
    }
    
    // Check if appointment would cross lunch break
    if (daySchedule.hasLunchBreak && daySchedule.lunchStart && daySchedule.lunchEnd) {
      const [lunchStartHours, lunchStartMinutes] = daySchedule.lunchStart.split(':').map(Number);
      const lunchStartInMinutes = lunchStartHours * 60 + lunchStartMinutes;
      
      const [lunchEndHours, lunchEndMinutes] = daySchedule.lunchEnd.split(':').map(Number);
      const lunchEndInMinutes = lunchEndHours * 60 + lunchEndMinutes;
      
      // Check if appointment would overlap with lunch break
      if (slotStartInMinutes < lunchEndInMinutes && slotEndInMinutes > lunchStartInMinutes) {
        return false;
      }
    }
    
    return true;
  };

  // CORREÇÃO: Função melhorada para gerar slots disponíveis
  const getAvailableTimeSlots = (date: Date): string[] => {
    const dayKey = getDayKey(date);
    const daySchedule = workingHours[dayKey];
    
    if (!daySchedule.isOpen) {
      return [];
    }
    
    // Get total duration of selected services
    const totalDuration = getTotalDuration();
    const serviceDuration = totalDuration > 0 ? totalDuration : 30; // Default to 30 if no services selected
    
    const timeSlots = [];
    const [startHours, startMinutes] = daySchedule.start.split(':').map(Number);
    const [endHours, endMinutes] = daySchedule.end.split(':').map(Number);
    
    const startInMinutes = startHours * 60 + startMinutes;
    const endInMinutes = endHours * 60 + endMinutes;
    
    console.log(`Generating slots for ${format(date, 'yyyy-MM-dd')} - service duration: ${serviceDuration}min`);
    
    // Gerar slots de 30 em 30 minutos (independente da duração do serviço)
    for (let minutes = startInMinutes; minutes < endInMinutes; minutes += 30) {
      const hours = Math.floor(minutes / 60);
      const mins = minutes % 60;
      const timeSlot = `${hours.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}`;
      
      // Verificar todas as condições: horário de funcionamento, almoço, conflitos e validade
      const isAvailable = isWithinWorkingHours(timeSlot, date) && 
                         !isLunchBreakSlot(timeSlot, date) && 
                         !isTimeSlotConflicted(timeSlot, date) && 
                         isTimeSlotValid(timeSlot, date);
      
      if (isAvailable) {
        timeSlots.push(timeSlot);
      } else {
        console.log(`Slot ${timeSlot} not available - lunch: ${isLunchBreakSlot(timeSlot, date)}, conflict: ${isTimeSlotConflicted(timeSlot, date)}, valid: ${isTimeSlotValid(timeSlot, date)}`);
      }
    }
    
    console.log(`Available slots for ${format(date, 'yyyy-MM-dd')}:`, timeSlots);
    return timeSlots;
  };

  const handleClientSelect = (client: any) => {
    console.log("Client selected:", client);
    setSelectedClient(client);
    setFormData(prev => ({
      ...prev,
      client: client.name,
      clientId: client.id,
      pet: "", // Reset pet selection when client changes
      services: [], // Reset service selection when client changes
      timeSlots: [] // Reset time slots when client changes
    }));
    setAvailablePets(client.pets.map((pet: any) => pet.name));
    setSelectedPet(null); // Reset selected pet
    setClientSearchOpen(false);
  };

  const handlePetSelect = (petName: string) => {
    const pet = selectedClient?.pets.find((p: any) => p.name === petName);
    setSelectedPet(pet);
    setFormData(prev => ({
      ...prev,
      pet: petName,
      services: [], // Reset service selection when pet changes
      timeSlots: [] // Reset time slots when pet changes
    }));
  };

  const handleServiceToggle = (serviceId: number) => {
    setFormData(prev => ({
      ...prev,
      services: prev.services.includes(serviceId)
        ? prev.services.filter(id => id !== serviceId)
        : [...prev.services, serviceId],
      timeSlots: [] // Reset time slots when services change as duration affects availability
    }));
  };

  const handleTimeSlotToggle = (timeSlot: string) => {
    setFormData(prev => ({
      ...prev,
      timeSlots: prev.timeSlots.includes(timeSlot)
        ? prev.timeSlots.filter(slot => slot !== timeSlot)
        : [...prev.timeSlots, timeSlot]
    }));
  };

  // Calculate total price from selected services
  const getTotalPrice = () => {
    return formData.services.reduce((total, serviceId) => {
      const service = availableServices.find(s => s.id === serviceId);
      return total + (service?.price || 0);
    }, 0);
  };

  // CORREÇÃO: Validação adicional no submit para evitar conflitos
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate if client is selected
    if (!formData.clientId) {
      toast({
        title: "Cliente não selecionado",
        description: "Por favor, selecione um cliente cadastrado.",
        variant: "destructive"
      });
      return;
    }

    // Validate if at least one service is selected
    if (formData.services.length === 0) {
      toast({
        title: "Nenhum serviço selecionado",
        description: "Por favor, selecione pelo menos um serviço.",
        variant: "destructive"
      });
      return;
    }

    // Validate if at least one time slot is selected
    if (formData.timeSlots.length === 0) {
      toast({
        title: "Nenhum horário selecionado",
        description: "Por favor, selecione pelo menos um horário.",
        variant: "destructive"
      });
      return;
    }

    // NOVA VALIDAÇÃO: Verificar conflitos antes de criar agendamentos
    const conflictingSlots = formData.timeSlots.filter(timeSlot => 
      isTimeSlotConflicted(timeSlot, formData.date)
    );

    if (conflictingSlots.length > 0) {
      toast({
        title: "Conflito de horários detectado",
        description: `Os horários ${conflictingSlots.join(', ')} não estão mais disponíveis. Por favor, selecione outros horários.`,
        variant: "destructive"
      });
      return;
    }
    
    const selectedServiceNames = formData.services.map(serviceId => {
      const service = availableServices.find(s => s.id === serviceId);
      return service?.name;
    }).filter(Boolean);

    // Create appointments for each selected time slot
    formData.timeSlots.forEach(timeSlot => {
      const newAppointment = {
        id: Date.now() + Math.random(), // Temporary ID generation
        client: formData.client,
        clientId: formData.clientId,
        pet: formData.pet,
        service: selectedServiceNames.join(", "),
        services: formData.services,
        date: formData.date,
        time: timeSlot,
        duration: getTotalDuration(),
        totalPrice: getTotalPrice(),
        taxiDog: formData.taxiDog,
        status: formData.status,
        createdBy: "Usuário Atual" // This would come from auth context in a real app
      };
      
      onSubmit(newAppointment);
    });
    
    onClose();
    
    // Reset form
    setFormData({
      client: "",
      clientId: null,
      pet: "",
      services: [],
      date: selectedDate || new Date(),
      timeSlots: [],
      taxiDog: false,
      status: "pending"
    });
    setSelectedClient(null);
    setAvailablePets([]);
  };

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(price);
  };

  // CHANGE: Only get time slots if pet, services, and date are all selected
  const shouldShowTimeSlots = selectedPet && formData.services.length > 0 && formData.date;
  const availableTimeSlots = shouldShowTimeSlots ? getAvailableTimeSlots(formData.date) : [];
  const isDayClosed = formData.date ? !workingHours[getDayKey(formData.date)].isOpen : false;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Novo Agendamento</DialogTitle>
          <DialogDescription>
            Preencha os dados para criar um novo agendamento no sistema.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="client">Cliente</Label>
            {displayClients.length === 0 ? (
              <div className="flex items-center space-x-2 p-2 bg-yellow-50 rounded-md">
                <AlertTriangle className="h-4 w-4 text-yellow-600" />
                <span className="text-sm text-yellow-600">
                  Nenhum cliente encontrado. Verifique se existem clientes cadastrados.
                </span>
              </div>
            ) : (
              <Popover open={clientSearchOpen} onOpenChange={setClientSearchOpen}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    aria-expanded={clientSearchOpen}
                    className="w-full justify-between"
                  >
                    {formData.client || "Selecionar cliente..."}
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-full p-0">
                  <Command>
                    <CommandInput placeholder="Buscar cliente..." />
                    <CommandEmpty>Nenhum cliente encontrado.</CommandEmpty>
                    <CommandList>
                      <CommandGroup>
                        {displayClients.map((client) => (
                          <CommandItem
                            key={client.id}
                            value={client.name}
                            onSelect={() => handleClientSelect(client)}
                          >
                            <Check
                              className={cn(
                                "mr-2 h-4 w-4",
                                formData.clientId === client.id ? "opacity-100" : "opacity-0"
                              )}
                            />
                            <div className="flex flex-col">
                              <span>{client.name}</span>
                              <span className="text-sm text-muted-foreground">{client.email}</span>
                            </div>
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
            )}
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="pet">Pet</Label>
            <Select 
              value={formData.pet} 
              onValueChange={handlePetSelect}
              disabled={!selectedClient}
            >
              <SelectTrigger>
                <SelectValue placeholder={selectedClient ? "Selecione o pet" : "Primeiro selecione um cliente"} />
              </SelectTrigger>
              <SelectContent>
                {selectedClient?.pets.map((pet: any) => (
                  <SelectItem key={pet.name} value={pet.name}>
                    {pet.name} ({pet.breed})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label>Serviços</Label>
            {!selectedPet ? (
              <p className="text-sm text-muted-foreground">Primeiro selecione um pet</p>
            ) : availableServices.length === 0 ? (
              <p className="text-sm text-muted-foreground">Nenhum serviço disponível para este pet</p>
            ) : (
              <div className="space-y-3 max-h-40 overflow-y-auto">
                {availableServices.map((service) => (
                  <div key={service.id} className="flex items-start space-x-3 p-3 border rounded-lg">
                    <Checkbox
                      id={`service-${service.id}`}
                      checked={formData.services.includes(service.id)}
                      onCheckedChange={() => handleServiceToggle(service.id)}
                    />
                    <div className="flex-1 min-w-0">
                      <label
                        htmlFor={`service-${service.id}`}
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                      >
                        {service.name}
                      </label>
                      <div className="text-sm text-muted-foreground mt-1">
                        {formatPrice(service.price)} • {service.durationMinutes} min
                      </div>
                    </div>
                  </div>
                ))}
                
                {formData.services.length > 0 && (
                  <div className="mt-3 p-3 bg-muted rounded-lg">
                    <div className="text-sm font-medium">Total: {formatPrice(getTotalPrice())}</div>
                    <div className="text-sm text-muted-foreground">Duração: {getTotalDuration()} min</div>
                  </div>
                )}
              </div>
            )}
          </div>
          
          <div className="space-y-2">
            <Label>Data</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !formData.date && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {formData.date ? format(formData.date, "dd/MM/yyyy", { locale: ptBR }) : "Selecionar data"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={formData.date}
                  onSelect={(date) => {
                    if (date) {
                      handleInputChange("date", date);
                      handleInputChange("timeSlots", []); // Reset time slots when date changes
                    }
                  }}
                  locale={ptBR}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>
          
          {/* CHANGED: Only show time slots section when pet, services, and date are all selected */}
          {shouldShowTimeSlots && (
            <div className="space-y-2">
              <Label>Horários Disponíveis</Label>
              {isDayClosed ? (
                <div className="flex items-center space-x-2 p-2 bg-red-50 rounded-md">
                  <AlertTriangle className="h-4 w-4 text-red-600" />
                  <span className="text-sm text-red-600">Fechado</span>
                </div>
              ) : availableTimeSlots.length === 0 ? (
                <div className="flex items-center space-x-2 p-2 bg-yellow-50 rounded-md">
                  <AlertTriangle className="h-4 w-4 text-yellow-600" />
                  <span className="text-sm text-yellow-600">
                    Sem horários disponíveis {formData.services.length > 0 ? `para serviços de ${getTotalDuration()} min` : ''}
                  </span>
                </div>
              ) : (
                <div className="grid grid-cols-3 gap-2 max-h-40 overflow-y-auto">
                  {availableTimeSlots.map((timeSlot) => (
                    <div key={timeSlot} className="flex items-center space-x-2">
                      <Checkbox
                        id={`time-${timeSlot}`}
                        checked={formData.timeSlots.includes(timeSlot)}
                        onCheckedChange={() => handleTimeSlotToggle(timeSlot)}
                      />
                      <label
                        htmlFor={`time-${timeSlot}`}
                        className="text-sm font-medium cursor-pointer"
                      >
                        {timeSlot}
                      </label>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
          
          <div className="flex items-center space-x-2">
            <Switch
              id="taxiDog"
              checked={formData.taxiDog}
              onCheckedChange={(checked) => handleInputChange("taxiDog", checked)}
            />
            <Label htmlFor="taxiDog">Serviço de Táxi Dog</Label>
          </div>
          
          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button 
              type="submit" 
              disabled={!shouldShowTimeSlots || isDayClosed || availableTimeSlots.length === 0 || formData.timeSlots.length === 0 || !formData.clientId || displayClients.length === 0 || formData.services.length === 0}
            >
              Criar Agendamento
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default NewAppointmentForm;

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Edit, Trash2, DollarSign, Scissors, Clock } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import DogBreedSelect from "@/components/ui/DogBreedSelect";
import { useDogBreeds } from "@/contexts/DogBreedContext";
import { usePetShopServices } from "@/contexts/PetShopServiceContext";
import { useToast } from "@/hooks/use-toast";

const PetShopServiceManager = () => {
  const { breeds } = useDogBreeds();
  const { services, addService, updateService, deleteService } = usePetShopServices();
  
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingService, setEditingService] = useState<any>(null);
  const [serviceName, setServiceName] = useState("");
  const [targetType, setTargetType] = useState<'breed' | 'size'>('breed');
  const [selectedBreed, setSelectedBreed] = useState("");
  const [selectedSize, setSelectedSize] = useState("");
  const [servicePrice, setServicePrice] = useState("");
  const [serviceDuration, setServiceDuration] = useState("");
  const { toast } = useToast();

  const sizeOptions = ["Pequeno", "Médio", "Grande", "Gigante"];

  const handleOpenDialog = (service?: any) => {
    if (service) {
      setEditingService(service);
      setServiceName(service.name);
      setTargetType(service.targetType);
      if (service.targetType === 'breed') {
        setSelectedBreed(service.targetValue);
        setSelectedSize("");
      } else {
        setSelectedSize(service.targetValue);
        setSelectedBreed("");
      }
      setServicePrice(service.price.toString());
      setServiceDuration(service.durationMinutes.toString());
    } else {
      setEditingService(null);
      setServiceName("");
      setTargetType('breed');
      setSelectedBreed("");
      setSelectedSize("");
      setServicePrice("");
      setServiceDuration("");
    }
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setEditingService(null);
    setServiceName("");
    setTargetType('breed');
    setSelectedBreed("");
    setSelectedSize("");
    setServicePrice("");
    setServiceDuration("");
  };

  const handleSubmit = () => {
    const targetValue = targetType === 'breed' ? selectedBreed : selectedSize;
    
    if (!serviceName || !targetValue || !servicePrice || !serviceDuration) {
      toast({
        title: "Erro",
        description: "Por favor, preencha todos os campos.",
        variant: "destructive",
      });
      return;
    }

    const price = parseFloat(servicePrice);
    const durationMinutes = parseInt(serviceDuration);
    
    if (isNaN(price) || price <= 0) {
      toast({
        title: "Erro",
        description: "Por favor, insira um valor válido para o preço.",
        variant: "destructive",
      });
      return;
    }

    if (isNaN(durationMinutes) || durationMinutes <= 0) {
      toast({
        title: "Erro",
        description: "Por favor, insira um tempo válido em minutos.",
        variant: "destructive",
      });
      return;
    }

    if (editingService) {
      updateService({ ...editingService, name: serviceName, targetType, targetValue, price, durationMinutes });
      toast({
        title: "Serviço atualizado!",
        description: `${serviceName} foi atualizado com sucesso.`,
      });
    } else {
      const newService = {
        id: Math.max(...services.map(s => s.id), 0) + 1,
        name: serviceName,
        targetType,
        targetValue,
        price,
        durationMinutes,
      };
      addService(newService);
      toast({
        title: "Serviço criado!",
        description: `${serviceName} foi adicionado com sucesso.`,
      });
    }

    handleCloseDialog();
  };

  const handleDelete = (serviceId: number) => {
    deleteService(serviceId);
    toast({
      title: "Serviço removido!",
      description: "O serviço foi removido com sucesso.",
    });
  };

  const handleTargetTypeChange = (value: 'breed' | 'size') => {
    setTargetType(value);
    setSelectedBreed("");
    setSelectedSize("");
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(price);
  };

  const getTargetDisplay = (service: any) => {
    return service.targetType === 'breed' 
      ? `Raça: ${service.targetValue}`
      : `Porte: ${service.targetValue}`;
  };

  const formatDuration = (minutes: number) => {
    if (minutes < 60) {
      return `${minutes} min`;
    } else {
      const hours = Math.floor(minutes / 60);
      const remainingMinutes = minutes % 60;
      return remainingMinutes > 0 ? `${hours}h ${remainingMinutes}min` : `${hours}h`;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Gerenciamento de Serviços</h2>
          <p className="text-gray-600">Gerencie os serviços oferecidos pelo seu pet shop</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button 
              onClick={() => handleOpenDialog()}
              className="bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white px-6 py-3 rounded-xl"
            >
              <Plus className="h-5 w-5 mr-2" />
              Adicionar Serviço
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>
                {editingService ? "Editar Serviço" : "Adicionar Novo Serviço"}
              </DialogTitle>
              <DialogDescription>
                {editingService 
                  ? "Faça as alterações necessárias no serviço."
                  : "Preencha as informações do novo serviço do pet shop."
                }
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="service-name">Nome do Serviço</Label>
                <Input
                  id="service-name"
                  value={serviceName}
                  onChange={(e) => setServiceName(e.target.value)}
                  placeholder="Ex: Banho e Tosa"
                />
              </div>
              
              <div className="space-y-3">
                <Label>Aplicar serviço por</Label>
                <RadioGroup 
                  value={targetType} 
                  onValueChange={handleTargetTypeChange}
                  className="flex space-x-6"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="breed" id="breed" />
                    <Label htmlFor="breed">Raça específica</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="size" id="size" />
                    <Label htmlFor="size">Porte do animal</Label>
                  </div>
                </RadioGroup>
              </div>

              {targetType === 'breed' ? (
                <div className="space-y-2">
                  <Label htmlFor="service-breed">Raça</Label>
                  <DogBreedSelect
                    value={selectedBreed}
                    onValueChange={setSelectedBreed}
                  />
                </div>
              ) : (
                <div className="space-y-2">
                  <Label htmlFor="service-size">Porte</Label>
                  <Select value={selectedSize} onValueChange={setSelectedSize}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o porte" />
                    </SelectTrigger>
                    <SelectContent>
                      {sizeOptions.map((size) => (
                        <SelectItem key={size} value={size}>
                          {size}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="service-price">Preço (R$)</Label>
                  <Input
                    id="service-price"
                    type="number"
                    step="0.01"
                    min="0"
                    value={servicePrice}
                    onChange={(e) => setServicePrice(e.target.value)}
                    placeholder="0,00"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="service-duration">Duração (minutos)</Label>
                  <Input
                    id="service-duration"
                    type="number"
                    min="1"
                    value={serviceDuration}
                    onChange={(e) => setServiceDuration(e.target.value)}
                    placeholder="60"
                  />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={handleCloseDialog}>
                Cancelar
              </Button>
              <Button onClick={handleSubmit}>
                {editingService ? "Atualizar" : "Adicionar"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Scissors className="h-5 w-5 mr-2 text-indigo-600" />
            Serviços Cadastrados
          </CardTitle>
        </CardHeader>
        <CardContent>
          {services.length === 0 ? (
            <div className="text-center py-8">
              <Scissors className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 text-lg mb-2">Nenhum serviço cadastrado</p>
              <p className="text-gray-400">Adicione um novo serviço para começar</p>
            </div>
          ) : (
            <div className="space-y-4">
              {services.map((service) => (
                <div key={service.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                  <div className="flex items-center space-x-4">
                    <div className="bg-indigo-100 p-3 rounded-xl">
                      <Scissors className="h-6 w-6 text-indigo-600" />
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-900">{service.name}</h3>
                      <p className="text-sm text-gray-600">{getTargetDisplay(service)}</p>
                      <div className="flex items-center space-x-4 mt-1">
                        <div className="flex items-center text-sm font-medium text-green-600">
                          <DollarSign className="h-4 w-4 mr-1" />
                          {formatPrice(service.price)}
                        </div>
                        <div className="flex items-center text-sm font-medium text-blue-600">
                          <Clock className="h-4 w-4 mr-1" />
                          {formatDuration(service.durationMinutes)}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleOpenDialog(service)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDelete(service.id)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default PetShopServiceManager;

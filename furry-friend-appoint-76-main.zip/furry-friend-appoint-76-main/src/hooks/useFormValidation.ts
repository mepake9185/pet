
import { useToast } from "@/hooks/use-toast";

interface Pet {
  name: string;
  breed: string;
}

interface FormData {
  email: string;
  phone: string;
}

export const useFormValidation = () => {
  const { toast } = useToast();

  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const formatPhone = (value: string) => {
    // Remove all non-numeric characters
    const cleanValue = value.replace(/\D/g, '');
    
    // Apply the format (11) 99999-9999
    if (cleanValue.length <= 2) {
      return `(${cleanValue}`;
    } else if (cleanValue.length <= 7) {
      return `(${cleanValue.slice(0, 2)}) ${cleanValue.slice(2)}`;
    } else {
      return `(${cleanValue.slice(0, 2)}) ${cleanValue.slice(2, 7)}-${cleanValue.slice(7, 11)}`;
    }
  };

  const validateForm = (formData: FormData, pets: Pet[]) => {
    // Validação do email
    if (!validateEmail(formData.email)) {
      toast({
        title: "Email inválido",
        description: "Por favor, insira um email válido.",
        variant: "destructive",
      });
      return false;
    }

    // Validação básica dos pets
    if (pets.some(pet => !pet.name || !pet.breed)) {
      toast({
        title: "Erro de validação",
        description: "Por favor, preencha o nome e raça de todos os pets.",
        variant: "destructive",
      });
      return false;
    }

    // Validate phone format
    const phoneDigits = formData.phone.replace(/\D/g, '');
    if (phoneDigits.length !== 11) {
      toast({
        title: "Erro de validação",
        description: "Por favor, insira um número de celular válido com 11 dígitos.",
        variant: "destructive",
      });
      return false;
    }

    return true;
  };

  return {
    validateEmail,
    formatPhone,
    validateForm
  };
};

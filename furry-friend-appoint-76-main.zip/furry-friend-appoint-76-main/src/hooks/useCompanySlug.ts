
import { useMemo } from 'react';
import { useParams, useLocation } from 'react-router-dom';

export interface CompanySlugInfo {
  slug: string | null;
  isValidSlug: boolean;
  normalizedSlug: string;
}

export const useCompanySlug = (): CompanySlugInfo => {
  const { companySlug } = useParams<{ companySlug: string }>();
  const location = useLocation();

  const slugInfo = useMemo(() => {
    // Extract slug from URL path
    const pathSegments = location.pathname.split('/').filter(segment => segment);
    const currentSlug = companySlug || pathSegments[0] || null;

    // Normalize slug (convert to lowercase, replace spaces with hyphens)
    const normalizedSlug = currentSlug ? 
      currentSlug.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '') : '';

    return {
      slug: currentSlug,
      isValidSlug: Boolean(currentSlug && currentSlug.length > 0),
      normalizedSlug
    };
  }, [companySlug, location.pathname]);

  return slugInfo;
};

export const generateSlugFromName = (companyName: string): string => {
  return companyName
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9-]/g, '')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
};

export const isValidSlugFormat = (slug: string): boolean => {
  const slugRegex = /^[a-z0-9]+(-[a-z0-9]+)*$/;
  return slugRegex.test(slug) && slug.length >= 3 && slug.length <= 50;
};

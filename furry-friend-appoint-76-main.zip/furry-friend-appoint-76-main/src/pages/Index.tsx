
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, PawPrint, Heart, Settings, User } from "lucide-react";
import { useNavigate } from "react-router-dom";
import PetshopDashboard from "@/components/PetshopDashboard";
import PetshopLogin from "@/components/PetshopLogin";
import ClientLogin from "@/components/ClientLogin";
import RegisteredClientLogin from "@/components/RegisteredClientLogin";
import ClientDashboard from "@/components/ClientDashboard";
import { useCompanyData } from "@/contexts/CompanyDataContext";

interface IndexProps {
  clientMode?: boolean;
}

const Index = ({ clientMode = false }: IndexProps) => {
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const { companyData } = useCompanyData();
  const navigate = useNavigate();

  // Define all handler functions first
  const handleClientAccess = () => {
    setSelectedOption("client");
  };

  const handleRegisteredClientAccess = () => {
    setSelectedOption("registered-client");
  };

  const handlePetshopAccess = () => {
    setSelectedOption("petshop");
  };

  const handlePetshopLoginSuccess = () => {
    setSelectedOption("dashboard");
  };

  const handleRegisteredClientLoginSuccess = () => {
    setSelectedOption("client-dashboard");
  };

  const handleBackToHome = () => {
    setSelectedOption(null);
  };

  // Handle component rendering based on selectedOption
  if (selectedOption === "client") {
    return <ClientLogin onBack={handleBackToHome} />;
  }

  if (selectedOption === "registered-client") {
    return <RegisteredClientLogin onBack={handleBackToHome} onLoginSuccess={handleRegisteredClientLoginSuccess} />;
  }

  if (selectedOption === "petshop") {
    return <PetshopLogin onLoginSuccess={handlePetshopLoginSuccess} onBack={handleBackToHome} />;
  }

  if (selectedOption === "dashboard") {
    return <PetshopDashboard />;
  }

  if (selectedOption === "client-dashboard") {
    return <ClientDashboard onLogout={handleBackToHome} />;
  }

  // If in client mode and we have company data, show client options directly
  if (clientMode && companyData.name) {
    // Show client access options for the specific company
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center p-4">
        <div className="w-full max-w-2xl">
          <div className="text-center mb-12">
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-3 rounded-2xl w-fit mx-auto mb-4">
              <PawPrint className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-gray-900 mb-4">{companyData.name}</h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Acesse sua área do cliente ou agende serviços para seu pet.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <Card className="group cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-1 border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardContent className="p-8 text-center">
                <div className="bg-gradient-to-r from-blue-500 to-blue-600 p-4 rounded-2xl w-fit mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <Calendar className="h-10 w-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Agendar Serviços</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Agende banho e tosa para seu pet com facilidade.
                </p>
                <Button 
                  onClick={handleClientAccess}
                  className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-medium py-3 rounded-xl"
                >
                  Sou Novo Cliente
                </Button>
              </CardContent>
            </Card>

            <Card className="group cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-1 border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardContent className="p-8 text-center">
                <div className="bg-gradient-to-r from-green-500 to-green-600 p-4 rounded-2xl w-fit mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                  <User className="h-10 w-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Cliente Cadastrado</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  Acesse sua área para gerenciar agendamentos.
                </p>
                <Button 
                  onClick={handleRegisteredClientAccess}
                  className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-medium py-3 rounded-xl"
                >
                  Entrar
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-8">
            <Button 
              variant="ghost" 
              onClick={() => navigate('/')}
              className="text-gray-600 hover:text-gray-800"
            >
              Voltar ao início
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Main page - no company selection needed
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-3 rounded-2xl">
              <PawPrint className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">PetSchedule</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Sistema inteligente de agendamentos para petshops. Simplifique seus agendamentos e melhore a experiência dos seus clientes.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* Client Option - redirects to company selection */}
          <Card className="group cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-1 border-0 shadow-lg bg-white/80 backdrop-blur-sm">
            <CardContent className="p-8 text-center">
              <div className="bg-gradient-to-r from-blue-500 to-blue-600 p-4 rounded-2xl w-fit mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                <Calendar className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Sou Cliente</h3>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Agende banho e tosa para seu pet. Acesse através do link da sua empresa.
              </p>
              <Button 
                onClick={handleClientAccess}
                className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-medium py-3 rounded-xl"
              >
                Acessar como Cliente
              </Button>
            </CardContent>
          </Card>

          {/* Petshop Option */}
          <Card className="group cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-1 border-0 shadow-lg bg-white/80 backdrop-blur-sm">
            <CardContent className="p-8 text-center">
              <div className="bg-gradient-to-r from-indigo-500 to-indigo-600 p-4 rounded-2xl w-fit mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                <Settings className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Sou Petshop</h3>
              <p className="text-gray-600 mb-6 leading-relaxed">
                Gerencie agendamentos, clientes e configurações do seu petshop.
              </p>
              <Button 
                onClick={handlePetshopAccess}
                className="w-full bg-gradient-to-r from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white font-medium py-3 rounded-xl"
              >
                Entrar como Petshop
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="text-center mt-12">
          <div className="flex items-center justify-center text-gray-500 text-sm">
            <span>Feito com</span>
            <Heart className="h-4 w-4 mx-1 text-red-500" />
            <span>para pets e seus donos</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;

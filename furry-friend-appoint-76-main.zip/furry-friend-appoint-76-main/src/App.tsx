
import React from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { DogBreedProvider } from "@/contexts/DogBreedContext";
import { CompanyRegistryProvider } from "@/contexts/CompanyRegistryContext";
import { CompanyDataProvider } from "@/contexts/CompanyDataContext";
import { ClientProvider } from "@/contexts/ClientContext";
import { PetShopServiceProvider } from "@/contexts/PetShopServiceContext";
import CompanyWrapper from "@/components/CompanyWrapper";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <CompanyRegistryProvider>
        <CompanyDataProvider>
          <ClientProvider>
            <DogBreedProvider>
              <PetShopServiceProvider>
                <Toaster />
                <Sonner />
                <BrowserRouter>
                  <Routes>
                    {/* Route for main page - no company selector needed */}
                    <Route path="/" element={<Index />} />
                    
                    {/* Routes for specific company client access */}
                    <Route 
                      path="/:companySlug/cliente" 
                      element={
                        <CompanyWrapper>
                          <Index clientMode={true} />
                        </CompanyWrapper>
                      } 
                    />
                    
                    {/* Routes for specific company management */}
                    <Route 
                      path="/:companySlug" 
                      element={
                        <CompanyWrapper>
                          <Index />
                        </CompanyWrapper>
                      } 
                    />
                    <Route 
                      path="/:companySlug/*" 
                      element={
                        <CompanyWrapper>
                          <Index />
                        </CompanyWrapper>
                      } 
                    />
                    
                    {/* Catch-all route */}
                    <Route path="*" element={<NotFound />} />
                  </Routes>
                </BrowserRouter>
              </PetShopServiceProvider>
            </DogBreedProvider>
          </ClientProvider>
        </CompanyDataProvider>
      </CompanyRegistryProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;

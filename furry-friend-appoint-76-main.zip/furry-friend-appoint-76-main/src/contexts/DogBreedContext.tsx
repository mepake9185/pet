
import { createContext, useContext, useState, ReactNode } from "react";

interface DogBreedContextType {
  breeds: string[];
  addBreed: (breed: string) => void;
  updateBreed: (oldBreed: string, newBreed: string) => void;
  deleteBreed: (breed: string) => void;
}

const DogBreedContext = createContext<DogBreedContextType | undefined>(undefined);

const initialBreeds = [
  "SRD",
  "Labrador Retriever",
  "Golden Retriever",
  "Pastor Alemão",
  "Bulldog Francês",
  "Poodle",
  "Rottweiler",
  "Yorkshire Terrier",
  "Beagle",
  "Dachshund",
  "Siberian Husky",
  "Shih Tzu",
  "Border Collie",
  "Boxer",
  "Cocker Spaniel",
  "Maltês",
  "Chihuahua",
  "Pug",
  "Akita",
  "Doberman",
  "Great Dane",
  "Pitbull",
  "Lhasa Apso",
  "Jack Russell Terrier",
  "Basset Hound",
  "Bernese Mountain Dog",
  "Boston Terrier",
  "Weimaraner",
  "Australian Shepherd",
  "Schnauzer"
];

export const DogBreedProvider = ({ children }: { children: ReactNode }) => {
  const [breeds, setBreeds] = useState<string[]>(initialBreeds);

  const addBreed = (breed: string) => {
    if (breed.trim() && !breeds.includes(breed.trim())) {
      setBreeds(prev => [...prev, breed.trim()].sort());
    }
  };

  const updateBreed = (oldBreed: string, newBreed: string) => {
    if (newBreed.trim() && !breeds.includes(newBreed.trim())) {
      setBreeds(prev => 
        prev.map(breed => breed === oldBreed ? newBreed.trim() : breed).sort()
      );
    }
  };

  const deleteBreed = (breedToDelete: string) => {
    setBreeds(prev => prev.filter(breed => breed !== breedToDelete));
  };

  return (
    <DogBreedContext.Provider value={{ breeds, addBreed, updateBreed, deleteBreed }}>
      {children}
    </DogBreedContext.Provider>
  );
};

export const useDogBreeds = () => {
  const context = useContext(DogBreedContext);
  if (context === undefined) {
    throw new Error('useDogBreeds must be used within a DogBreedProvider');
  }
  return context;
};

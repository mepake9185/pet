
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { generateSlugFromName, isValidSlugFormat } from '@/hooks/useCompanySlug';

interface RegisteredCompany {
  id: string;
  name: string;
  slug: string;
  email: string;
  phone: string;
  isActive: boolean;
  createdAt: string;
}

interface CompanyRegistryContextType {
  companies: RegisteredCompany[];
  getCompanyBySlug: (slug: string) => RegisteredCompany | undefined;
  registerCompany: (companyData: Omit<RegisteredCompany, 'id' | 'slug' | 'createdAt'>) => RegisteredCompany;
  updateCompany: (id: string, data: Partial<RegisteredCompany>) => void;
  isSlugAvailable: (slug: string) => boolean;
}

const CompanyRegistryContext = createContext<CompanyRegistryContextType | undefined>(undefined);

const COMPANIES_STORAGE_KEY = 'companies-registry';

const defaultCompanies: RegisteredCompany[] = [
  {
    id: '1',
    name: 'Pet Shop Exemplo',
    slug: 'pet-shop-exemplo',
    email: 'contato@petshop.com',
    phone: '(11) 99999-9999',
    isActive: true,
    createdAt: new Date().toISOString()
  }
];

export const CompanyRegistryProvider = ({ children }: { children: ReactNode }) => {
  const [companies, setCompanies] = useState<RegisteredCompany[]>(() => {
    try {
      const savedCompanies = localStorage.getItem(COMPANIES_STORAGE_KEY);
      if (savedCompanies) {
        return JSON.parse(savedCompanies);
      }
    } catch (error) {
      console.error('Erro ao carregar empresas:', error);
    }
    return defaultCompanies;
  });

  useEffect(() => {
    try {
      localStorage.setItem(COMPANIES_STORAGE_KEY, JSON.stringify(companies));
    } catch (error) {
      console.error('Erro ao salvar empresas:', error);
    }
  }, [companies]);

  const getCompanyBySlug = (slug: string) => {
    return companies.find(company => company.slug === slug && company.isActive);
  };

  const isSlugAvailable = (slug: string) => {
    if (!isValidSlugFormat(slug)) return false;
    return !companies.some(company => company.slug === slug);
  };

  const registerCompany = (companyData: Omit<RegisteredCompany, 'id' | 'slug' | 'createdAt'>) => {
    const baseSlug = generateSlugFromName(companyData.name);
    let finalSlug = baseSlug;
    let counter = 1;

    // Ensure unique slug
    while (!isSlugAvailable(finalSlug)) {
      finalSlug = `${baseSlug}-${counter}`;
      counter++;
    }

    const newCompany: RegisteredCompany = {
      ...companyData,
      id: Date.now().toString(),
      slug: finalSlug,
      createdAt: new Date().toISOString()
    };

    setCompanies(prev => [...prev, newCompany]);
    return newCompany;
  };

  const updateCompany = (id: string, data: Partial<RegisteredCompany>) => {
    setCompanies(prev => prev.map(company => 
      company.id === id ? { ...company, ...data } : company
    ));
  };

  return (
    <CompanyRegistryContext.Provider value={{
      companies,
      getCompanyBySlug,
      registerCompany,
      updateCompany,
      isSlugAvailable
    }}>
      {children}
    </CompanyRegistryContext.Provider>
  );
};

export const useCompanyRegistry = () => {
  const context = useContext(CompanyRegistryContext);
  if (context === undefined) {
    throw new Error('useCompanyRegistry must be used within a CompanyRegistryProvider');
  }
  return context;
};

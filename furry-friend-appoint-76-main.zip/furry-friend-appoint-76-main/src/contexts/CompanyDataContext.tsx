
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface WorkingHours {
  monday: { start: string; end: string; lunchStart: string; lunchEnd: string; isOpen: boolean; hasLunchBreak: boolean };
  tuesday: { start: string; end: string; lunchStart: string; lunchEnd: string; isOpen: boolean; hasLunchBreak: boolean };
  wednesday: { start: string; end: string; lunchStart: string; lunchEnd: string; isOpen: boolean; hasLunchBreak: boolean };
  thursday: { start: string; end: string; lunchStart: string; lunchEnd: string; isOpen: boolean; hasLunchBreak: boolean };
  friday: { start: string; end: string; lunchStart: string; lunchEnd: string; isOpen: boolean; hasLunchBreak: boolean };
  saturday: { start: string; end: string; lunchStart: string; lunchEnd: string; isOpen: boolean; hasLunchBreak: boolean };
  sunday: { start: string; end: string; lunchStart: string; lunchEnd: string; isOpen: boolean; hasLunchBreak: boolean };
}

interface CompanyData {
  name: string;
  slug: string;
  phone: string;
  email: string;
  cep: string;
  address: string;
  addressNumber: string;
  complement: string;
  neighborhood: string;
  city: string;
  state: string;
  workingHours: WorkingHours;
}

interface CompanyDataContextType {
  companyData: CompanyData;
  updateCompanyData: (data: Partial<CompanyData>) => void;
  loadCompanyDataBySlug: (slug: string) => void;
  currentCompanySlug: string | null;
}

const defaultCompanyData: CompanyData = {
  name: "Pet Shop Exemplo",
  slug: "pet-shop-exemplo",
  phone: "(11) 99999-9999",
  email: "contato@petshop.com",
  cep: "",
  address: "",
  addressNumber: "",
  complement: "",
  neighborhood: "",
  city: "",
  state: "",
  workingHours: {
    monday: { start: "08:00", end: "18:00", lunchStart: "12:00", lunchEnd: "13:00", isOpen: true, hasLunchBreak: true },
    tuesday: { start: "08:00", end: "18:00", lunchStart: "", lunchEnd: "", isOpen: true, hasLunchBreak: false },
    wednesday: { start: "08:00", end: "20:00", lunchStart: "12:00", lunchEnd: "13:00", isOpen: true, hasLunchBreak: true },
    thursday: { start: "08:00", end: "18:00", lunchStart: "", lunchEnd: "", isOpen: true, hasLunchBreak: false },
    friday: { start: "08:00", end: "18:00", lunchStart: "12:00", lunchEnd: "13:00", isOpen: true, hasLunchBreak: true },
    saturday: { start: "08:00", end: "14:00", lunchStart: "", lunchEnd: "", isOpen: true, hasLunchBreak: false },
    sunday: { start: "08:00", end: "12:00", lunchStart: "", lunchEnd: "", isOpen: false, hasLunchBreak: false },
  }
};

const CompanyDataContext = createContext<CompanyDataContextType | undefined>(undefined);

export const CompanyDataProvider = ({ children }: { children: ReactNode }) => {
  const [companyData, setCompanyData] = useState<CompanyData>(defaultCompanyData);
  const [currentCompanySlug, setCurrentCompanySlug] = useState<string | null>(null);

  const getStorageKey = (slug: string) => `company-data-${slug}`;

  const loadCompanyDataBySlug = (slug: string) => {
    setCurrentCompanySlug(slug);
    try {
      const savedData = localStorage.getItem(getStorageKey(slug));
      if (savedData) {
        const parsedData = JSON.parse(savedData);
        setCompanyData(prev => ({ ...prev, ...parsedData, slug }));
      } else {
        // Set default data with the current slug
        setCompanyData(prev => ({ ...prev, slug }));
      }
    } catch (error) {
      console.error('Erro ao carregar dados da empresa:', error);
      setCompanyData(prev => ({ ...prev, slug }));
    }
  };

  const updateCompanyData = (data: Partial<CompanyData>) => {
    const updatedData = { ...companyData, ...data };
    setCompanyData(updatedData);
    
    if (currentCompanySlug) {
      try {
        localStorage.setItem(getStorageKey(currentCompanySlug), JSON.stringify(updatedData));
      } catch (error) {
        console.error('Erro ao salvar dados da empresa:', error);
      }
    }
  };

  // Load default company on mount if no slug is set
  useEffect(() => {
    if (!currentCompanySlug) {
      loadCompanyDataBySlug(defaultCompanyData.slug);
    }
  }, [currentCompanySlug]);

  return (
    <CompanyDataContext.Provider value={{ 
      companyData, 
      updateCompanyData, 
      loadCompanyDataBySlug,
      currentCompanySlug
    }}>
      {children}
    </CompanyDataContext.Provider>
  );
};

export const useCompanyData = () => {
  const context = useContext(CompanyDataContext);
  if (context === undefined) {
    throw new Error('useCompanyData must be used within a CompanyDataProvider');
  }
  return context;
};

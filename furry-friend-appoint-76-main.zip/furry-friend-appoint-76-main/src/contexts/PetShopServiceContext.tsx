
import React, { createContext, useContext, useState, ReactNode } from 'react';

interface PetShopService {
  id: number;
  name: string;
  targetType: 'breed' | 'size';
  targetValue: string;
  price: number;
  durationMinutes: number;
}

interface PetShopServiceContextType {
  services: PetShopService[];
  setServices: (services: PetShopService[]) => void;
  addService: (service: PetShopService) => void;
  updateService: (service: PetShopService) => void;
  deleteService: (serviceId: number) => void;
}

const PetShopServiceContext = createContext<PetShopServiceContextType | undefined>(undefined);

export const usePetShopServices = () => {
  const context = useContext(PetShopServiceContext);
  if (!context) {
    throw new Error('usePetShopServices must be used within a PetShopServiceProvider');
  }
  return context;
};

interface PetShopServiceProviderProps {
  children: ReactNode;
}

export const PetShopServiceProvider: React.FC<PetShopServiceProviderProps> = ({ children }) => {
  const [services, setServices] = useState<PetShopService[]>([
    { id: 1, name: "Banho e Tosa", targetType: 'breed', targetValue: "Golden Retriever", price: 80.00, durationMinutes: 90 },
    { id: 2, name: "Banho Simples", targetType: 'size', targetValue: "Pequeno", price: 50.00, durationMinutes: 45 },
    { id: 3, name: "Tosa Higiênica", targetType: 'breed', targetValue: "Yorkshire", price: 35.00, durationMinutes: 30 },
    { id: 4, name: "Banho e Tosa", targetType: 'size', targetValue: "Grande", price: 100.00, durationMinutes: 120 },
    { id: 5, name: "Banho Simples", targetType: 'breed', targetValue: "Poodle", price: 60.00, durationMinutes: 60 },
  ]);

  const addService = (service: PetShopService) => {
    setServices(prev => [...prev, service]);
  };

  const updateService = (updatedService: PetShopService) => {
    setServices(prev => prev.map(service => 
      service.id === updatedService.id ? updatedService : service
    ));
  };

  const deleteService = (serviceId: number) => {
    setServices(prev => prev.filter(service => service.id !== serviceId));
  };

  return (
    <PetShopServiceContext.Provider value={{
      services,
      setServices,
      addService,
      updateService,
      deleteService
    }}>
      {children}
    </PetShopServiceContext.Provider>
  );
};


import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';

interface Pet {
  name: string;
  breed: string;
}

interface Client {
  id: number;
  name: string;
  email: string;
  phone: string;
  cep: string;
  address: string;
  addressNumber: string;
  complement: string;
  neighborhood: string;
  city: string;
  state: string;
  pets: Pet[];
  companySlug: string;
}

interface ClientContextType {
  clients: Client[];
  addClient: (client: Omit<Client, 'id'>) => void;
  updateClient: (client: Client) => void;
  getClientById: (id: number) => Client | undefined;
  getClientByEmail: (email: string, companySlug?: string) => Client | undefined;
  getClientsByCompany: (companySlug: string) => Client[];
  currentClient: Client | null;
  setCurrentClient: (client: Client | null) => void;
  setCurrentCompanySlug: (slug: string) => void;
  currentCompanySlug: string | null;
}

const ClientContext = createContext<ClientContextType | undefined>(undefined);

const defaultClients: Client[] = [
  {
    id: 1,
    name: "Maria Silva",
    email: "maria.silva@email.com",
    phone: "(11) 99999-1234",
    cep: "01310-100",
    address: "Av. Paulista",
    addressNumber: "1578",
    complement: "Apto 101",
    neighborhood: "Bela Vista",
    city: "São Paulo",
    state: "SP",
    companySlug: "pet-shop-exemplo",
    pets: [
      { name: "Rex", breed: "Golden Retriever" },
      { name: "Luna", breed: "Poodle" }
    ]
  },
  {
    id: 2,
    name: "João Santos",
    email: "joao.santos@email.com",
    phone: "(11) 98888-5678",
    cep: "04038-001",
    address: "Rua Vergueiro",
    addressNumber: "3185",
    complement: "",
    neighborhood: "Vila Mariana",
    city: "São Paulo",
    state: "SP",
    companySlug: "pet-shop-exemplo",
    pets: [
      { name: "Max", breed: "Labrador" }
    ]
  }
];

export const ClientProvider = ({ children }: { children: ReactNode }) => {
  const [clients, setClients] = useState<Client[]>(() => {
    const savedClients = localStorage.getItem('petshop-clients');
    if (savedClients) {
      try {
        const parsedClients = JSON.parse(savedClients);
        // Ensure all clients have a companySlug (for backward compatibility)
        return parsedClients.map((client: any) => ({
          ...client,
          companySlug: client.companySlug || "pet-shop-exemplo"
        }));
      } catch (error) {
        console.error('Error parsing saved clients:', error);
        return defaultClients;
      }
    }
    return defaultClients;
  });

  const [currentClient, setCurrentClient] = useState<Client | null>(null);
  const [currentCompanySlug, setCurrentCompanySlug] = useState<string | null>(null);

  useEffect(() => {
    localStorage.setItem('petshop-clients', JSON.stringify(clients));
  }, [clients]);

  const addClient = (clientData: Omit<Client, 'id'>) => {
    const newId = Math.max(...clients.map(c => c.id), 0) + 1;
    const newClient: Client = {
      ...clientData,
      id: newId
    };
    setClients(prev => [...prev, newClient]);
  };

  const updateClient = (updatedClient: Client) => {
    setClients(prev => prev.map(client => 
      client.id === updatedClient.id ? updatedClient : client
    ));
  };

  const getClientById = (id: number) => {
    return clients.find(client => client.id === id);
  };

  const getClientByEmail = (email: string, companySlug?: string) => {
    return clients.find(client => {
      const emailMatch = client.email.toLowerCase() === email.toLowerCase();
      if (companySlug) {
        return emailMatch && client.companySlug === companySlug;
      }
      return emailMatch;
    });
  };

  const getClientsByCompany = (companySlug: string) => {
    return clients.filter(client => client.companySlug === companySlug);
  };

  return (
    <ClientContext.Provider value={{ 
      clients, 
      addClient, 
      updateClient, 
      getClientById, 
      getClientByEmail,
      getClientsByCompany,
      currentClient,
      setCurrentClient,
      setCurrentCompanySlug,
      currentCompanySlug
    }}>
      {children}
    </ClientContext.Provider>
  );
};

export const useClients = () => {
  const context = useContext(ClientContext);
  if (context === undefined) {
    throw new Error('useClients must be used within a ClientProvider');
  }
  return context;
};
